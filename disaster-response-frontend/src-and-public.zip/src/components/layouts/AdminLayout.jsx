import React, { useState, useEffect, useCallback } from 'react';
import { NavLink, Link, Outlet, useLocation } from 'react-router-dom';
import {
  ShieldAlert,
  Users,
  Building,
  Cpu,
  Radio,
  Settings,
  Activity,
  Menu,
  X,
  LayoutDashboard,
  BarChart3,
  UserCheck,
} from 'lucide-react';
import PortalHeaderControls from '../common/PortalHeaderControls';
import SidebarLogoutButton from '../common/SidebarLogoutButton';
import incidentService from '../../services/incidentService';

const AdminLayout = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [backendOnline, setBackendOnline] = useState(true);
  const location = useLocation();

  const checkHealth = useCallback(async () => {
    const isOnline = await incidentService.checkBackendHealth();
    setBackendOnline(isOnline);
  }, []);

  useEffect(() => {
    checkHealth();
    const interval = setInterval(checkHealth, 15000);
    return () => clearInterval(interval);
  }, [checkHealth]);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [location.pathname]);

  const navItems = [
    { name: 'Dashboard', path: '/admin', icon: LayoutDashboard, end: true },
    { name: 'Users', path: '/admin/users', icon: Users },
    { name: 'Authorities', path: '/admin/authorities', icon: Building },
    { name: 'Incidents', path: '/admin/incidents', icon: Radio },
    { name: 'Response Teams', path: '/admin/teams', icon: UserCheck },
    { name: 'IoT Sensors', path: '/admin/sensors', icon: Cpu },
    { name: 'Analytics', path: '/admin/analytics', icon: BarChart3 },
    { name: 'System Settings', path: '/admin/settings', icon: Settings },
    { name: 'System Health', path: '/admin/health', icon: Activity },
  ];

  return (
    <div className="min-h-screen bg-[#F3F6FA] text-[#172033] flex font-sans">
      {/* Mobile Backdrop */}
      {isMobileMenuOpen && (
        <div
          className="fixed inset-0 z-40 bg-slate-900/40 lg:hidden transition-opacity"
          onClick={() => setIsMobileMenuOpen(false)}
          aria-hidden="true"
        />
      )}

      {/* Admin Sidebar */}
      <aside
        className={`fixed top-0 bottom-0 left-0 z-40 flex w-60 flex-col justify-between border-r border-[#E5E7EB] bg-white p-3 transition-transform duration-200 ease-in-out lg:translate-x-0 ${
          isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="space-y-4">
          {/* Brand Header */}
          <div className="flex items-center justify-between pb-3 border-b border-[#E5E7EB]">
            <Link
              to="/admin"
              onClick={() => setIsMobileMenuOpen(false)}
              className="flex items-center gap-2.5"
            >
              <div className="flex h-8 w-8 items-center justify-center rounded-md bg-[#1D4ED8] text-white">
                <ShieldAlert className="w-4 h-4" />
              </div>
              <div>
                <h2 className="text-xs font-bold text-[#111827] leading-tight">
                  Admin Console
                </h2>
                <span className="text-[10px] text-[#64748B] block">
                  System Administration
                </span>
              </div>
            </Link>

            <button
              type="button"
              onClick={() => setIsMobileMenuOpen(false)}
              className="lg:hidden p-1 rounded-md text-[#64748B] hover:bg-slate-100 hover:text-[#111827]"
              aria-label="Close menu"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Navigation Links */}
          <nav className="space-y-0.5">
            <div className="px-2.5 pb-1.5 text-[10px] font-semibold uppercase tracking-wider text-[#64748B]">
              Administration
            </div>
            {navItems.map((item) => {
              const Icon = item.icon;
              return (
                <NavLink
                  key={item.path}
                  to={item.path}
                  end={item.end}
                  onClick={() => setIsMobileMenuOpen(false)}
                  className={({ isActive }) =>
                    `group flex items-center justify-between rounded-md px-2.5 py-2 text-xs font-medium transition-colors ${
                      isActive
                        ? 'bg-blue-50 text-[#1D4ED8] font-semibold'
                        : 'text-[#64748B] hover:bg-slate-50 hover:text-[#111827]'
                    }`
                  }
                >
                  {({ isActive }) => (
                    <div className="flex items-center gap-2.5">
                      <Icon
                        className={`w-4 h-4 transition-colors ${
                          isActive ? 'text-[#1D4ED8]' : 'text-[#64748B] group-hover:text-[#111827]'
                        }`}
                      />
                      <span>{item.name}</span>
                    </div>
                  )}
                </NavLink>
              );
            })}
          </nav>
        </div>

        <div className="border-t border-[#E2E8F0] pt-3">
          <SidebarLogoutButton />
        </div>

      </aside>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 lg:pl-60 transition-all duration-200">
        <header className="sticky top-0 z-30 flex h-16 w-full items-center justify-between border-b border-[#E2E8F0] bg-white px-4 sm:px-6 shadow-[0_1px_3px_rgba(15,23,42,0.08)]">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => setIsMobileMenuOpen((prev) => !prev)}
              className="lg:hidden p-1.5 rounded-md border border-[#E5E7EB] bg-white text-[#64748B] hover:text-[#111827] hover:bg-slate-50 focus:outline-none"
              aria-label="Toggle Navigation"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2">
              <span className="text-sm font-bold text-[#111827]">System Administration</span>
              <span className="hidden sm:inline-block text-[10px] font-semibold px-1.5 py-0.5 rounded bg-slate-100 text-slate-700 border border-slate-200">
                ADMIN
              </span>
            </div>
          </div>

          <PortalHeaderControls backendOnline={backendOnline} />
        </header>

        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default AdminLayout;
