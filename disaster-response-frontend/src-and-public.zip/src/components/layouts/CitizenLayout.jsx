import React, { useCallback, useEffect, useState } from 'react';
import { NavLink, Link, Outlet, useLocation } from 'react-router-dom';
import { ShieldAlert, PlusCircle, Menu, X, LayoutDashboard, FileText, Bell, BookOpen } from 'lucide-react';
import PortalHeaderControls from '../common/PortalHeaderControls';
import SidebarLogoutButton from '../common/SidebarLogoutButton';
import incidentService from '../../services/incidentService';

const CitizenLayout = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [backendOnline, setBackendOnline] = useState(true);
  const location = useLocation();

  const checkHealth = useCallback(async () => setBackendOnline(await incidentService.checkBackendHealth()), []);

  useEffect(() => {
    checkHealth();
    const interval = setInterval(checkHealth, 15000);
    return () => clearInterval(interval);
  }, [checkHealth]);

  useEffect(() => window.scrollTo(0, 0), [location.pathname]);

  const navLinks = [
    { name: 'Dashboard', path: '/citizen', icon: LayoutDashboard, end: true },
    { name: 'Report Incident', path: '/citizen/report', icon: PlusCircle },
    { name: 'My Reports', path: '/citizen/reports', icon: FileText },
    { name: 'Notifications', path: '/citizen/notifications', icon: Bell },
    { name: 'Safety Guide', path: '/citizen/guide', icon: BookOpen },
  ];

  return (
    <div className="min-h-screen bg-[#F4F6F9] text-[#172033] font-sans">
      {isMobileMenuOpen && <button type="button" className="fixed inset-0 z-40 bg-slate-900/30 lg:hidden" onClick={() => setIsMobileMenuOpen(false)} aria-label="Close navigation" />}

      <aside className={`fixed inset-y-0 left-0 z-50 flex w-60 flex-col border-r border-[#E2E8F0] bg-white p-3 transition-transform duration-200 lg:translate-x-0 ${isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <div>
          <div className="flex items-start justify-between border-b border-[#E2E8F0] pb-4">
            <Link to="/citizen" onClick={() => setIsMobileMenuOpen(false)} className="flex items-center gap-2.5">
              <span className="flex h-8 w-8 items-center justify-center rounded-md bg-[#2563EB] text-white"><ShieldAlert className="h-4 w-4" /></span>
              <span>
                <span className="block text-xs font-bold text-[#172033]">Smart Disaster Management</span>
                <span className="mt-0.5 block text-[10px] text-[#64748B]">Citizen Portal &bull; Public Emergency Services</span>
              </span>
            </Link>
            <button type="button" onClick={() => setIsMobileMenuOpen(false)} className="p-1 text-[#64748B] lg:hidden" aria-label="Close navigation"><X className="h-4 w-4" /></button>
          </div>

          <nav className="mt-4 space-y-0.5">
            <p className="px-2.5 pb-1.5 text-[10px] font-semibold uppercase tracking-wider text-[#64748B]">Citizen menu</p>
            {navLinks.map(({ name, path, icon: Icon, end }) => (
              <NavLink key={path} to={path} end={end} onClick={() => setIsMobileMenuOpen(false)} className={({ isActive }) => `flex items-center gap-2.5 rounded-md px-2.5 py-2 text-xs font-medium transition-colors ${isActive ? 'bg-blue-50 text-[#2563EB]' : 'text-[#64748B] hover:bg-slate-50 hover:text-[#172033]'}`}>
                <Icon className="h-4 w-4" />
                {name}
              </NavLink>
            ))}
          </nav>
        </div>

        <div className="mt-auto border-t border-[#E2E8F0] pt-3"><SidebarLogoutButton /></div>
      </aside>

      <div className="flex min-h-screen flex-col lg:pl-60">
        <header className="sticky top-0 z-30 flex h-16 items-center justify-between border-b border-[#E2E8F0] bg-white px-4 sm:px-6 shadow-[0_1px_3px_rgba(15,23,42,0.08)]">
          <div className="flex items-center gap-3">
            <button type="button" onClick={() => setIsMobileMenuOpen((open) => !open)} className="rounded-md border border-[#E2E8F0] p-1.5 text-[#64748B] lg:hidden" aria-label="Toggle navigation"><Menu className="h-5 w-5" /></button>
            <div>
              <h1 className="text-sm font-semibold text-[#172033]">Welcome back, Citizen</h1>
              <p className="hidden text-xs text-[#64748B] sm:block">Public emergency reporting and incident tracking</p>
            </div>
          </div>
          <div className="flex items-center gap-2.5">
            {location.pathname !== '/citizen/report' && <Link to="/citizen/report" className="inline-flex items-center gap-1.5 rounded-md bg-[#2563EB] px-3 py-1.5 text-xs font-semibold text-white transition-colors hover:bg-blue-700"><PlusCircle className="h-3.5 w-3.5" />Report Incident</Link>}
            <PortalHeaderControls backendOnline={backendOnline} />
          </div>
        </header>
        <main className="mx-auto w-full max-w-7xl flex-1 p-4 sm:p-6 lg:p-8"><Outlet /></main>
      </div>
    </div>
  );
};

export default CitizenLayout;
