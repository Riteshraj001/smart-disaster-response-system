import React, { useEffect, useRef } from 'react';
import L from 'leaflet';
import { MapPin, Info } from 'lucide-react';
import StatusBadge from '../common/StatusBadge';
import DisasterIcon from '../common/DisasterIcon';

// Helper to extract lat/lng from text like "28.6139, 77.2090" or "Coordinates: 28.61, 77.20"
const extractCoordinates = (locStr) => {
  if (!locStr || typeof locStr !== 'string') return null;
  const match = locStr.match(/(-?\d+(\.\d+)?),\s*(-?\d+(\.\d+)?)/);
  if (match) {
    const lat = parseFloat(match[1]);
    const lng = parseFloat(match[3]);
    if (!isNaN(lat) && !isNaN(lng) && lat >= -90 && lat <= 90 && lng >= -180 && lng <= 180) {
      return [lat, lng];
    }
  }
  return null;
};

const IncidentMap = ({ incidents = [], center = [20.5937, 78.9629], zoom = 5 }) => {
  const mapContainerRef = useRef(null);
  const mapInstanceRef = useRef(null);
  const markersLayerRef = useRef(null);

  // Separate incidents that have coordinates vs those with text locations
  const geocodedIncidents = incidents
    .map((inc) => ({
      ...inc,
      coords: extractCoordinates(inc.location),
    }))
    .filter((inc) => inc.coords !== null);

  const nonGeocodedIncidents = incidents.filter(
    (inc) => extractCoordinates(inc.location) === null
  );

  useEffect(() => {
    if (!mapContainerRef.current) return;

    // Initialize Leaflet map if not already created
    if (!mapInstanceRef.current) {
      const map = L.map(mapContainerRef.current, {
        center: center,
        zoom: zoom,
        zoomControl: true,
        attributionControl: true,
      });

      // Standard clean OpenStreetMap / CartoDB Voyager tiles
      L.tileLayer(
        'https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png',
        {
          attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>',
          maxZoom: 19,
          subdomains: 'abcd',
        }
      ).addTo(map);

      markersLayerRef.current = L.layerGroup().addTo(map);
      mapInstanceRef.current = map;
    }

    const map = mapInstanceRef.current;
    const markersLayer = markersLayerRef.current;

    // Clear previous markers
    if (markersLayer) {
      markersLayer.clearLayers();
    }

    // Add markers for geocoded incidents
    if (geocodedIncidents.length > 0 && markersLayer) {
      const bounds = L.latLngBounds();

      geocodedIncidents.forEach((inc) => {
        const [lat, lng] = inc.coords;
        bounds.extend([lat, lng]);

        const statusLower = (inc.status || '').toLowerCase();
        const pinColor =
          statusLower === 'active'
            ? '#dc2626'
            : statusLower === 'pending'
            ? '#d97706'
            : '#059669';

        const customIcon = L.divIcon({
          className: 'custom-map-marker',
          html: `
            <div style="
              background-color: ${pinColor};
              width: 26px;
              height: 26px;
              border-radius: 50%;
              border: 2.5px solid #ffffff;
              box-shadow: 0 2px 6px rgba(0,0,0,0.25);
              display: flex;
              align-items: center;
              justify-content: center;
              color: #ffffff;
              font-size: 10px;
              font-weight: 700;
              cursor: pointer;
            ">
              #${inc.id}
            </div>
          `,
          iconSize: [26, 26],
          iconAnchor: [13, 13],
          popupAnchor: [0, -14],
        });

        const marker = L.marker([lat, lng], { icon: customIcon });

        const popupContent = `
          <div style="min-width: 170px; padding: 2px;">
            <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 4px;">
              <span style="font-size: 11px; font-weight: 700; color: #475569;">#${inc.id}</span>
              <span style="font-size: 11px; font-weight: 700; color: ${pinColor};">${inc.status}</span>
            </div>
            <h4 style="font-size: 13px; font-weight: 700; color: #0f172a; margin: 0 0 2px 0;">${inc.disasterType}</h4>
            <p style="font-size: 11px; color: #64748b; margin: 0 0 8px 0;">${inc.location}</p>
            <a href="/authority/incidents/${inc.id}" style="
              display: inline-block;
              background-color: #1e40af;
              color: #ffffff;
              padding: 4px 10px;
              border-radius: 6px;
              font-size: 11px;
              font-weight: 600;
              text-decoration: none;
            ">View Operations &rarr;</a>
          </div>
        `;

        marker.bindPopup(popupContent);
        markersLayer.addLayer(marker);
      });

      if (geocodedIncidents.length > 1) {
        map.fitBounds(bounds, { padding: [40, 40] });
      } else if (geocodedIncidents.length === 1) {
        map.setView(geocodedIncidents[0].coords, 10);
      }
    }
  }, [geocodedIncidents, center, zoom]);

  return (
    <div className="space-y-4">
      {/* Map Container */}
      <div className="relative rounded-xl overflow-hidden border border-slate-200 bg-white shadow-xs">
        <div ref={mapContainerRef} className="h-[440px] w-full z-10" />

        {/* Map Overlay Status */}
        <div className="absolute top-3 right-3 z-20 flex flex-col gap-2">
          <div className="px-3 py-1.5 rounded-lg bg-white/95 border border-slate-200 text-xs font-semibold text-slate-700 shadow-xs flex items-center gap-2">
            <span className="h-2 w-2 rounded-full bg-emerald-500" />
            <span>{geocodedIncidents.length} GPS Pin(s) Rendered</span>
          </div>
        </div>
      </div>

      {/* Notice for text-only incidents (No fake coordinates!) */}
      {nonGeocodedIncidents.length > 0 && (
        <div className="rounded-xl border border-slate-200 bg-white p-4 sm:p-5 shadow-xs">
          <div className="flex items-start gap-3">
            <Info className="w-5 h-5 text-blue-700 shrink-0 mt-0.5" />
            <div className="space-y-2 flex-1">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                <h4 className="text-sm font-bold text-slate-900">
                  Location Text Records ({nonGeocodedIncidents.length})
                </h4>
                <span className="text-xs text-slate-500">
                  Coordinates appear automatically for numeric lat/long reports
                </span>
              </div>
              <p className="text-xs text-slate-600">
                The incidents below are currently registered with city/area text names without latitude/longitude coordinates:
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5 pt-1">
                {nonGeocodedIncidents.map((inc) => (
                  <div
                    key={inc.id}
                    className="p-2.5 rounded-lg border border-slate-200 bg-slate-50 flex items-center justify-between gap-2"
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <DisasterIcon type={inc.disasterType} className="w-4 h-4 shrink-0" />
                      <div className="truncate">
                        <p className="text-xs font-bold text-slate-900 truncate">
                          #{inc.id} {inc.disasterType}
                        </p>
                        <p className="text-[11px] text-slate-500 truncate flex items-center gap-1">
                          <MapPin className="w-3 h-3 text-slate-400 shrink-0" />
                          {inc.location}
                        </p>
                      </div>
                    </div>
                    <StatusBadge status={inc.status} size="sm" />
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default IncidentMap;

