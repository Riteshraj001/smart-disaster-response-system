import React from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';

const roleHome = { citizen: '/citizen', authority: '/authority', admin: '/admin' };

const PublicOnly = ({ children }) => {
  const { session, isReady } = useAuth();
  if (!isReady) {
    return <div className="flex min-h-screen items-center justify-center bg-[#F4F6F9] text-sm text-[#64748B]">Loading...</div>;
  }
  return session ? <Navigate to={roleHome[session.role] || '/'} replace /> : children;
};

export default PublicOnly;
