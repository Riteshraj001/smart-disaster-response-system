import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';

const roleHome = {
  citizen: '/citizen',
  authority: '/authority',
  admin: '/admin',
};

const RequireRole = ({ role, children }) => {
  const { session, isReady } = useAuth();
  const location = useLocation();

  if (!isReady) {
    return <div className="flex min-h-screen items-center justify-center bg-[#F4F6F9] text-sm text-[#64748B]">Loading...</div>;
  }

  if (!session) {
    return <Navigate to={`/login/${role}`} replace state={{ from: location.pathname }} />;
  }

  if (session.role !== role) {
    return <Navigate to={roleHome[session.role] || '/'} replace />;
  }

  return children;
};

export default RequireRole;
