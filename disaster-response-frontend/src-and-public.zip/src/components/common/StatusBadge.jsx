import React from 'react';
import { STATUS_CONFIG } from '../../constants/incidentConstants';

const StatusBadge = ({ status, size = 'md', pulse = false }) => {
  const rawStatus = (status || '').trim().toLowerCase();

  let key = 'Pending';
  if (rawStatus === 'active') key = 'Active';
  else if (rawStatus === 'resolved') key = 'Resolved';
  else key = 'Pending';

  const config = STATUS_CONFIG[key] || STATUS_CONFIG.Pending;

  const sizeClasses =
    size === 'sm'
      ? 'px-2 py-0.5 text-xs gap-1.5'
      : size === 'lg'
      ? 'px-3 py-1 text-sm font-semibold gap-2'
      : 'px-2.5 py-0.5 text-xs font-medium gap-1.5';

  return (
    <span
      className={`inline-flex items-center rounded-full border ${config.badgeBg} ${config.badgeText} ${config.badgeBorder} ${sizeClasses} transition-all`}
      title={`Status: ${config.label} — ${config.description}`}
    >
      <span
        className={`h-1.5 w-1.5 rounded-full ${config.dotBg} shrink-0 ${
          pulse && key === 'Active' ? 'animate-pulse' : ''
        }`}
      />
      <span>{config.label}</span>
    </span>
  );
};

export default StatusBadge;

