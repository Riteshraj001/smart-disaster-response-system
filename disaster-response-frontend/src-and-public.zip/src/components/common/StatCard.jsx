import React from 'react';
import { ArrowUpRight } from 'lucide-react';

const StatCard = ({
  title,
  value = 0,
  icon: Icon,
  variant = 'default',
  subtitle,
  onClick,
  active = false,
  badgeText,
}) => {
  const variantStyles = {
    default: {
      border: 'border-[#E5E7EB]',
      iconBg: 'bg-[#F5F7FA] text-[#111827]',
      valueColor: 'text-[#111827]',
    },
    active: {
      border: 'border-red-200',
      iconBg: 'bg-red-50 text-[#DC2626]',
      valueColor: 'text-[#DC2626]',
    },
    pending: {
      border: 'border-amber-200',
      iconBg: 'bg-amber-50 text-[#D97706]',
      valueColor: 'text-[#D97706]',
    },
    resolved: {
      border: 'border-emerald-200',
      iconBg: 'bg-emerald-50 text-[#059669]',
      valueColor: 'text-[#059669]',
    },
    primary: {
      border: 'border-blue-200',
      iconBg: 'bg-blue-50 text-[#1D4ED8]',
      valueColor: 'text-[#1D4ED8]',
    },
  };

  const style = variantStyles[variant] || variantStyles.default;

  return (
    <div
      onClick={onClick}
      className={`rounded-lg bg-white p-4 sm:p-5 border shadow-xs transition-colors ${
        active ? 'ring-2 ring-[#1D4ED8] border-[#1D4ED8]' : style.border
      } ${onClick ? 'cursor-pointer hover:border-slate-300' : ''}`}
    >
      <div className="flex items-start justify-between">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold uppercase tracking-wider text-[#64748B]">
              {title}
            </span>
            {badgeText && (
              <span className="text-[10px] font-medium px-1.5 py-0.5 rounded bg-[#F5F7FA] text-[#64748B] border border-[#E5E7EB]">
                {badgeText}
              </span>
            )}
          </div>
          <div className="flex items-baseline gap-2">
            <span className={`text-2xl sm:text-3xl font-bold tracking-tight ${style.valueColor}`}>
              {value}
            </span>
          </div>
        </div>

        {Icon && (
          <div className={`p-2 rounded-md ${style.iconBg}`}>
            <Icon className="w-5 h-5" />
          </div>
        )}
      </div>

      {subtitle && (
        <div className="mt-3 flex items-center justify-between pt-2 border-t border-[#E5E7EB] text-xs text-[#64748B]">
          <span>{subtitle}</span>
          {onClick && (
            <span className="flex items-center text-[#1D4ED8] font-medium hover:underline">
              Filter <ArrowUpRight className="w-3.5 h-3.5 ml-0.5" />
            </span>
          )}
        </div>
      )}
    </div>
  );
};

export default StatCard;


