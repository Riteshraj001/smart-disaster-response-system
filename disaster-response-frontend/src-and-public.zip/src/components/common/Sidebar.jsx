import React from 'react';
import { NavLink } from 'react-router-dom';
import {
  LayoutDashboard,
  Radio,
  PlusCircle,
  BarChart3,
  Info,
  ShieldAlert,
  Server,
  X,
  Map,
  Users,
  Cpu,
  CheckCircle2,
  AlertCircle,
} from 'lucide-react';

const navItems = [
  {
    name: 'Dashboard',
    path: '/authority',
    icon: LayoutDashboard,
  },
  {
    name: 'Incidents',
    path: '/authority/incidents',
    icon: Radio,
  },
  {
    name: 'Report Incident',
    path: '/citizen/report',
    icon: PlusCircle,
  },
  {
    name: 'Incident Map',
    path: '/authority/map',
    icon: Map,
  },
  {
    name: 'Analytics',
    path: '/authority/analytics',
    icon: BarChart3,
  },
  {
    name: 'Response Teams',
    path: '/authority/teams',
    icon: Users,
  },
  {
    name: 'IoT Sensors',
    path: '/authority/sensors',
    icon: Cpu,
  },
  {
    name: 'About System',
    path: '/about',
    icon: Info,
  },
];

const Sidebar = ({ isMobileOpen, onMobileClose, backendOnline = true }) => {
  return (
    <>
      {/* Mobile Backdrop */}
      {isMobileOpen && (
        <div
          className="fixed inset-0 z-40 bg-slate-900/40 lg:hidden transition-opacity"
          onClick={onMobileClose}
          aria-hidden="true"
        />
      )}

      {/* Sidebar Container */}
      <aside
        className={`fixed top-0 bottom-0 left-0 z-40 flex w-60 flex-col justify-between border-r border-[#E5E7EB] bg-white p-3 transition-transform duration-200 ease-in-out lg:translate-x-0 ${
          isMobileOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Top: Identity & Navigation */}
        <div className="space-y-4">
          {/* Top Brand Identity */}
          <div className="flex items-center justify-between pb-3 border-b border-[#E5E7EB]">
            <NavLink
              to="/"
              onClick={() => onMobileClose && onMobileClose()}
              className="flex items-center gap-2.5"
            >
              <div className="flex h-8 w-8 items-center justify-center rounded-md bg-[#1D4ED8] text-white">
                <ShieldAlert className="w-4 h-4" />
              </div>
              <div>
                <h2 className="text-xs font-bold text-[#111827] leading-tight">
                  Smart Disaster Mgmt
                </h2>
                <span className="text-[10px] text-[#64748B] block">
                  Operations Portal
                </span>
              </div>
            </NavLink>

            {/* Mobile close button */}
            <button
              type="button"
              onClick={onMobileClose}
              className="lg:hidden p-1 rounded-md text-[#64748B] hover:bg-slate-100 hover:text-[#111827]"
              aria-label="Close navigation"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Navigation Links */}
          <nav className="space-y-0.5">
            <div className="px-2.5 pb-1.5 text-[10px] font-semibold uppercase tracking-wider text-[#64748B]">
              Navigation
            </div>
            {navItems.map((item) => {
              const Icon = item.icon;
              return (
                <NavLink
                  key={item.path}
                  to={item.path}
                  end={item.path === '/authority'}
                  onClick={() => onMobileClose && onMobileClose()}
                  className={({ isActive }) =>
                    `group flex items-center justify-between rounded-md px-2.5 py-2 text-xs font-medium transition-colors ${
                      isActive
                        ? 'bg-blue-50 text-[#1D4ED8] font-semibold'
                        : 'text-[#64748B] hover:bg-slate-50 hover:text-[#111827]'
                    }`
                  }
                >
                  {({ isActive }) => (
                    <div className="flex items-center gap-2.5">
                      <Icon
                        className={`w-4 h-4 transition-colors ${
                          isActive
                            ? 'text-[#1D4ED8]'
                            : 'text-[#64748B] group-hover:text-[#111827]'
                        }`}
                      />
                      <span>{item.name}</span>
                    </div>
                  )}
                </NavLink>
              );
            })}
          </nav>
        </div>

        {/* Bottom Section: System Status */}
        <div className="pt-3 border-t border-[#E5E7EB] space-y-2">
          <div className="rounded-md border border-[#E5E7EB] bg-[#F5F7FA] p-2.5 space-y-1.5 text-[11px]">
            <div className="flex items-center justify-between font-medium text-[#111827]">
              <span>System Status</span>
              {backendOnline ? (
                <span className="inline-flex items-center gap-1 text-[#059669] font-semibold">
                  <CheckCircle2 className="w-3 h-3" />
                  Operational
                </span>
              ) : (
                <span className="inline-flex items-center gap-1 text-[#DC2626] font-semibold">
                  <AlertCircle className="w-3 h-3" />
                  Offline
                </span>
              )}
            </div>

            <div className="flex items-center justify-between text-[#64748B] pt-1 border-t border-[#E5E7EB]">
              <span>API (Port 8080)</span>
              <span className={backendOnline ? 'text-[#059669] font-medium' : 'text-[#DC2626] font-medium'}>
                {backendOnline ? 'Online' : 'Offline'}
              </span>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
};

export default Sidebar;


