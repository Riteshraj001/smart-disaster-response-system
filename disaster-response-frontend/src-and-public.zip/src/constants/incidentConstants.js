export const DISASTER_TYPES = [
  'Fire',
  'Flood',
  'Earthquake',
  'Landslide',
  'Cyclone',
  'Accident',
  'Smoke',
  'Tsunami',
  'Industrial Hazard',
  'Other',
];

export const INCIDENT_STATUSES = [
  'Pending',
  'Active',
  'Resolved',
];

export const SEVERITY_LEVELS = [
  'Low',
  'Medium',
  'High',
  'Critical',
];

export const SEVERITY_CONFIG = {
  Low: {
    label: 'Low',
    description: 'Minor localized incident, routine monitoring',
    badgeBg: 'bg-emerald-50',
    badgeText: 'text-emerald-700',
    badgeBorder: 'border-emerald-200',
    dotBg: 'bg-emerald-500',
    iconColor: 'text-emerald-600',
    indicator: '🟢',
  },
  Medium: {
    label: 'Medium',
    description: 'Moderate hazard, requires field response unit',
    badgeBg: 'bg-amber-50',
    badgeText: 'text-amber-700',
    badgeBorder: 'border-amber-200',
    dotBg: 'bg-amber-500',
    iconColor: 'text-amber-600',
    indicator: '🟡',
  },
  High: {
    label: 'High',
    description: 'Severe threat to life, assets, or infrastructure',
    badgeBg: 'bg-orange-50',
    badgeText: 'text-orange-700',
    badgeBorder: 'border-orange-200',
    dotBg: 'bg-orange-500',
    iconColor: 'text-orange-600',
    indicator: '🟠',
  },
  Critical: {
    label: 'Critical',
    description: 'Catastrophic event requiring multi-agency mass dispatch',
    badgeBg: 'bg-red-50',
    badgeText: 'text-red-700',
    badgeBorder: 'border-red-200',
    dotBg: 'bg-red-600',
    iconColor: 'text-red-600',
    indicator: '🔴',
  },
};

export const INCIDENT_SOURCES = {
  MANUAL: 'MANUAL',
  SENSOR: 'SENSOR',
};

export const STATUS_CONFIG = {
  Pending: {
    label: 'Pending',
    displayLabel: 'Pending Verification',
    description: 'Awaiting authority triage & verification',
    badgeBg: 'bg-amber-50',
    badgeText: 'text-amber-800',
    badgeBorder: 'border-amber-200',
    dotBg: 'bg-amber-500',
    pingColor: 'bg-amber-400',
    statBg: 'bg-white',
    statBorder: 'border-slate-200',
    iconColor: 'text-amber-600',
    indicator: '🟡',
    step: 1,
  },
  Active: {
    label: 'Active',
    displayLabel: 'Active',
    description: 'Emergency response actively underway',
    badgeBg: 'bg-red-50',
    badgeText: 'text-red-700',
    badgeBorder: 'border-red-200',
    dotBg: 'bg-red-600',
    pingColor: 'bg-red-500',
    statBg: 'bg-white',
    statBorder: 'border-slate-200',
    iconColor: 'text-red-600',
    indicator: '🔴',
    step: 2,
  },
  Resolved: {
    label: 'Resolved',
    displayLabel: 'Resolved',
    description: 'Emergency handled and contained. Completed record.',
    badgeBg: 'bg-emerald-50',
    badgeText: 'text-emerald-700',
    badgeBorder: 'border-emerald-200',
    dotBg: 'bg-emerald-600',
    pingColor: 'bg-emerald-400',
    statBg: 'bg-white',
    statBorder: 'border-slate-200',
    iconColor: 'text-emerald-600',
    indicator: '🟢',
    step: 3,
  },
};

export const RESPONSE_TEAMS = [
  'Unassigned',
  'North Zone Rapid Fire Engine',
  'NDRF Heavy Rescue Battalion',
  'Trauma & Paramedic Ambulance Fleet',
  'Police Perimeter & Evacuation Squad',
  'Special Hazmat Unit',
  'Coastal Marine Rescue Squad',
];

export const EMERGENCY_HELPLINES = [
  { name: 'National Emergency Number', number: '112', desc: 'Unified 24/7 all-emergency dispatch' },
  { name: 'Fire Emergency', number: '101', desc: 'Fire brigade & hazardous rescue' },
  { name: 'Police Helpline', number: '100', desc: 'Law enforcement & security' },
  { name: 'Ambulance & EMS', number: '102 / 108', desc: 'Medical emergency & paramedic' },
  { name: 'Disaster Management Helpline', number: '1070 / 1077', desc: 'National/State Disaster Response Force' },
];

export const IOT_SENSOR_TYPES = [
  {
    id: 'IOT-SMK-101',
    name: 'Smoke / Gas Detector (MQ-2)',
    type: 'Smoke',
    zone: 'Industrial Sector 4',
    location: 'North Chemical Complex',
    status: 'Online',
    battery: '98%',
    lastSeen: '10s ago',
    reading: '42 PPM (Normal)',
    node: 'ESP32 Node-01',
  },
  {
    id: 'IOT-FLM-204',
    name: 'Infrared Flame Sensor (IR Optical)',
    type: 'Fire',
    zone: 'Forest Edge Sector 9',
    location: 'Pine Valley Border',
    status: 'Online',
    battery: '94%',
    lastSeen: '5s ago',
    reading: 'No Flame Detected',
    node: 'ESP32 Node-02',
  },
  {
    id: 'IOT-WTR-308',
    name: 'Ultrasonic Water Level Gauge',
    type: 'Water Level',
    zone: 'River Basin Gate 3',
    location: 'East River Bridge',
    status: 'Online',
    battery: '89%',
    lastSeen: '15s ago',
    reading: '3.4m (Safe Margin)',
    node: 'ESP32 Node-03',
  },
  {
    id: 'IOT-TMP-415',
    name: 'Thermal Environment Sensor (DHT22)',
    type: 'Temperature',
    zone: 'Central Warehouse B',
    location: 'Cold Storage Room 2',
    status: 'Online',
    battery: '91%',
    lastSeen: '30s ago',
    reading: '24.2°C (Optimal)',
    node: 'ESP32 Node-04',
  },
];

export const API_BASE_URL = 'http://localhost:8080';
