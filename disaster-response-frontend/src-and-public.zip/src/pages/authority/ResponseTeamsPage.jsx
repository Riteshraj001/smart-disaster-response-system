import React from 'react';
import { Users, Phone, MapPin, Shield, CheckCircle2 } from 'lucide-react';

const ResponseTeamsPage = () => {
  const teams = [
    {
      id: 'UNIT-FIRE-01',
      name: 'North Zone Fire & Rescue',
      type: 'Fire & Hazardous Rescue',
      commander: 'Captain R. Verma',
      status: 'On Standby',
      personnel: 8,
      station: 'Central Fire Station 4',
      contact: '101 / +91 98765 43210',
    },
    {
      id: 'UNIT-NDRF-03',
      name: 'NDRF Rescue Battalion',
      type: 'Earthquake & Flood Response',
      commander: 'Major S. K. Singh',
      status: 'Field Deployed',
      personnel: 24,
      station: 'State Disaster Command HQ',
      contact: '1070 / +91 98111 22334',
    },
    {
      id: 'UNIT-EMS-08',
      name: 'Trauma & Paramedic Ambulance Fleet',
      type: 'Emergency Medical Service',
      commander: 'Dr. A. Sharma',
      status: 'On Standby',
      personnel: 6,
      station: 'District Civil Hospital',
      contact: '102 / +91 98444 55667',
    },
    {
      id: 'UNIT-POL-12',
      name: 'Police Perimeter & Traffic Squad',
      type: 'Law Enforcement & Evacuation',
      commander: 'Inspector M. Patel',
      status: 'On Standby',
      personnel: 12,
      station: 'Sector 19 Police Station',
      contact: '100 / +91 98999 88776',
    },
  ];

  return (
    <div className="space-y-6 font-sans">
      <div className="pb-2 border-b border-[#E5E7EB]">
        <h1 className="text-xl sm:text-2xl font-bold text-[#111827]">
          Response Teams &amp; Emergency Units
        </h1>
        <p className="text-xs sm:text-sm text-[#64748B] mt-0.5">
          Directory of registered emergency response teams, equipment readiness, and dispatch contacts.
        </p>
      </div>

      {/* Unit Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {teams.map((team) => {
          const isDeployed = team.status === 'Field Deployed';
          return (
            <div
              key={team.id}
              className="bg-white border border-[#E5E7EB] rounded-lg p-5 shadow-xs space-y-4 flex flex-col justify-between"
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-[#64748B]">{team.id}</span>
                  <span
                    className={`text-xs px-2 py-0.5 rounded font-semibold border ${
                      isDeployed
                        ? 'bg-amber-50 text-[#D97706] border-amber-200'
                        : 'bg-emerald-50 text-[#059669] border-emerald-200'
                    }`}
                  >
                    {team.status}
                  </span>
                </div>

                <div>
                  <h3 className="text-sm font-bold text-[#111827]">{team.name}</h3>
                  <p className="text-xs text-[#1D4ED8] font-medium mt-0.5">{team.type}</p>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs pt-1">
                  <div className="p-2.5 rounded-md border border-[#E5E7EB] bg-[#F5F7FA]">
                    <span className="text-[#64748B] block text-[11px]">Commander</span>
                    <span className="font-semibold text-[#111827]">{team.commander}</span>
                  </div>
                  <div className="p-2.5 rounded-md border border-[#E5E7EB] bg-[#F5F7FA]">
                    <span className="text-[#64748B] block text-[11px]">Personnel</span>
                    <span className="font-semibold text-[#111827]">{team.personnel} Responders</span>
                  </div>
                </div>
              </div>

              <div className="pt-3 border-t border-[#E5E7EB] flex items-center justify-between text-xs text-[#64748B]">
                <span className="flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5" />
                  {team.station}
                </span>
                <span className="text-[#1D4ED8] font-semibold flex items-center gap-1">
                  <Phone className="w-3 h-3" />
                  {team.contact}
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default ResponseTeamsPage;

