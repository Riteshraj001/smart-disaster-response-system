import React, { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import {
  ArrowLeft,
  Edit3,
  Trash2,
  MapPin,
  Clock,
  Radio,
  Users,
  FileText,
  CheckCircle2,
  AlertTriangle,
  Calendar,
} from 'lucide-react';
import incidentService from '../../services/incidentService';
import { useNotification } from '../../context/NotificationContext';
import DisasterIcon from '../../components/common/DisasterIcon';
import StatusBadge from '../../components/common/StatusBadge';
import SourceBadge from '../../components/common/SourceBadge';
import SeverityBadge from '../../components/common/SeverityBadge';
import LifecycleActionModal from '../../components/common/LifecycleActionModal';
import LoadingSpinner from '../../components/common/LoadingSpinner';
import ErrorAlert from '../../components/common/ErrorAlert';

const AuthorityIncidentDetailsPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { showToast } = useNotification();

  const [incident, setIncident] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  // Modal State
  const [modalState, setModalState] = useState({
    isOpen: false,
    action: 'verify',
    isProcessing: false,
  });

  const fetchIncident = useCallback(async () => {
    try {
      setIsLoading(true);
      setError(null);
      const data = await incidentService.getIncidentById(id);
      setIncident(data);
    } catch (err) {
      console.error('Error fetching incident details:', err);
      if (err.statusCode === 404) {
        setError(`Incident #${id} was not found.`);
      } else {
        setError(err.message || 'Unable to fetch incident details.');
      }
    } finally {
      setIsLoading(false);
    }
  }, [id]);

  useEffect(() => {
    fetchIncident();
  }, [fetchIncident]);

  const openActionModal = (action) => {
    setModalState({
      isOpen: true,
      action,
      isProcessing: false,
    });
  };

  const closeModal = () => {
    if (!modalState.isProcessing) {
      setModalState({
        isOpen: false,
        action: 'verify',
        isProcessing: false,
      });
    }
  };

  const handleModalConfirm = async (payload = {}) => {
    const { action } = modalState;
    if (!incident) return;

    setModalState((prev) => ({ ...prev, isProcessing: true }));

    try {
      if (action === 'verify') {
        const updated = await incidentService.verifyAndActivate(incident.id, incident, payload);
        setIncident(updated);
        showToast(`Incident #${incident.id} verified and marked as Active.`, 'success');
      } else if (action === 'reject') {
        const updated = await incidentService.rejectIncident(incident.id, incident, payload.reason);
        setIncident(updated);
        showToast(`Incident #${incident.id} rejected.`, 'info');
      } else if (action === 'resolve') {
        const updated = await incidentService.resolveIncident(incident.id, incident, payload.notes);
        setIncident(updated);
        showToast(`Incident #${incident.id} marked as Resolved.`, 'success');
      } else if (action === 'delete') {
        await incidentService.deleteIncident(incident.id);
        showToast(`Incident #${incident.id} deleted.`, 'success');
        navigate('/authority/incidents');
        return;
      }
      closeModal();
    } catch (err) {
      console.error(`Error during action [${action}]:`, err);
      showToast(err.message || 'Action failed on server.', 'error');
      setModalState((prev) => ({ ...prev, isProcessing: false }));
    }
  };

  if (isLoading) {
    return (
      <div className="max-w-4xl mx-auto py-12">
        <LoadingSpinner message={`Loading record for Incident #${id}...`} />
      </div>
    );
  }

  if (error || !incident) {
    return (
      <div className="max-w-4xl mx-auto space-y-6 font-sans">
        <Link
          to="/authority/incidents"
          className="inline-flex items-center gap-1.5 text-xs font-medium text-[#64748B] hover:text-[#111827] transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Incidents</span>
        </Link>
        <ErrorAlert
          title="Incident Record Unavailable"
          message={error || 'The requested incident could not be retrieved.'}
          onRetry={fetchIncident}
        />
      </div>
    );
  }

  const rawStatus = (incident.status || 'Pending').trim().toLowerCase();
  const isPending = rawStatus === 'pending';
  const isActive = rawStatus === 'active';
  const isResolved = rawStatus === 'resolved';

  // Format reported timestamp
  const formatTimestamp = (dateStr) => {
    if (!dateStr) return '20 Aug 2026, 10:42 AM';
    try {
      const d = new Date(dateStr);
      if (isNaN(d.getTime())) return dateStr;
      return d.toLocaleString('en-GB', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      });
    } catch {
      return dateStr;
    }
  };

  // Timeline Step calculation:
  // 1: Detected (always completed)
  // 2: Verified (completed if active or resolved)
  // 3: Response Dispatched (completed if active or resolved)
  // 4: Resolved (completed if resolved)
  const timelineSteps = [
    { label: 'Detected', completed: true, current: isPending },
    { label: 'Verified', completed: isActive || isResolved, current: isPending },
    { label: 'Response Dispatched', completed: isActive || isResolved, current: isActive },
    { label: 'Resolved', completed: isResolved, current: isResolved },
  ];

  return (
    <div className="max-w-4xl mx-auto space-y-6 font-sans">
      {/* Top Breadcrumb & Action Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <Link
          to="/authority/incidents"
          className="inline-flex items-center gap-1.5 text-xs font-medium text-[#64748B] hover:text-[#111827] transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Incidents</span>
        </Link>

        <div className="flex items-center gap-2">
          {!isResolved && (
            <Link
              to={`/authority/incidents/${incident.id}/edit`}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md border border-[#E5E7EB] bg-white hover:bg-slate-50 text-xs font-medium text-[#111827] transition-colors"
            >
              <Edit3 className="w-3.5 h-3.5" />
              <span>Edit Details</span>
            </Link>
          )}

          <button
            type="button"
            onClick={() => openActionModal('delete')}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md border border-red-200 bg-white hover:bg-red-50 text-xs font-medium text-[#DC2626] transition-colors"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Delete</span>
          </button>
        </div>
      </div>

      {/* Main Incident Record Container */}
      <div className="bg-white border border-[#E5E7EB] rounded-lg shadow-xs overflow-hidden">
        {/* Record Header */}
        <div className="p-6 border-b border-[#E5E7EB] flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white">
          <div className="flex items-center gap-3.5">
            <DisasterIcon type={incident.disasterType} showContainer size="md" />
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-bold text-[#111827]">
                  Incident #{incident.id}
                </h1>
                <StatusBadge status={incident.status} size="sm" />
              </div>
              <p className="text-xs text-[#64748B] mt-0.5">
                Official Incident Record &bull; Emergency Coordination
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <SourceBadge source={incident.source || 'MANUAL'} size="md" />
            <SeverityBadge severity={incident.severity || 'Medium'} size="md" />
          </div>
        </div>

        {/* 8. Incident Details Key Fields */}
        <div className="p-6 space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6 text-sm">
            <div className="space-y-1">
              <span className="text-xs text-[#64748B] font-medium block">Disaster Type</span>
              <p className="font-semibold text-[#111827]">{incident.disasterType}</p>
            </div>

            <div className="space-y-1">
              <span className="text-xs text-[#64748B] font-medium block">Location</span>
              <p className="font-semibold text-[#111827] flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-[#64748B]" />
                {incident.location}
              </p>
            </div>

            <div className="space-y-1">
              <span className="text-xs text-[#64748B] font-medium block">Source</span>
              <p className="font-semibold text-[#111827]">
                {incident.source === 'SENSOR' ? 'IoT Sensor' : 'Citizen Report'}
              </p>
            </div>

            <div className="space-y-1">
              <span className="text-xs text-[#64748B] font-medium block">Severity</span>
              <p className="font-semibold text-[#111827]">{incident.severity || 'Medium'}</p>
            </div>

            <div className="space-y-1">
              <span className="text-xs text-[#64748B] font-medium block">Status</span>
              <p className="font-semibold text-[#111827]">{incident.status || 'Pending'}</p>
            </div>

            <div className="space-y-1">
              <span className="text-xs text-[#64748B] font-medium block">Reported</span>
              <p className="font-semibold text-[#111827] flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5 text-[#64748B]" />
                {formatTimestamp(incident.reportedAt || incident.createdAt)}
              </p>
            </div>
          </div>

          {/* Description / Details */}
          {incident.description && (
            <div className="pt-4 border-t border-[#E5E7EB] space-y-1.5">
              <span className="text-xs text-[#64748B] font-medium block">Description</span>
              <p className="text-sm text-[#111827] bg-[#F5F7FA] p-3 rounded-md border border-[#E5E7EB] leading-relaxed">
                {incident.description}
              </p>
            </div>
          )}

          {/* Response Team & Notes */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
            <div className="p-3.5 rounded-md border border-[#E5E7EB] bg-[#F5F7FA] space-y-1">
              <span className="text-xs text-[#64748B] font-medium block flex items-center gap-1">
                <Users className="w-3.5 h-3.5" />
                Assigned Response Team
              </span>
              <p className="text-sm font-semibold text-[#111827]">
                {incident.assignedTeam || 'Unassigned'}
              </p>
            </div>

            <div className="p-3.5 rounded-md border border-[#E5E7EB] bg-[#F5F7FA] space-y-1">
              <span className="text-xs text-[#64748B] font-medium block flex items-center gap-1">
                <FileText className="w-3.5 h-3.5" />
                Response Notes
              </span>
              <p className="text-xs text-[#111827]">
                {incident.responseNotes || 'No notes added yet.'}
              </p>
            </div>
          </div>

          {/* 8. Incident Timeline */}
          <div className="pt-6 border-t border-[#E5E7EB] space-y-4">
            <h3 className="text-sm font-bold text-[#111827]">
              Incident Timeline
            </h3>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {timelineSteps.map((step, idx) => (
                <div
                  key={step.label}
                  className={`p-3 rounded-md border text-center ${
                    step.completed
                      ? 'bg-emerald-50 border-emerald-200 text-[#059669]'
                      : 'bg-[#F5F7FA] border-[#E5E7EB] text-[#64748B]'
                  }`}
                >
                  <div className="flex items-center justify-center mb-1">
                    {step.completed ? (
                      <CheckCircle2 className="w-4 h-4 text-[#059669]" />
                    ) : (
                      <span className="w-4 h-4 rounded-full border border-[#64748B] text-[10px] flex items-center justify-center font-bold">
                        {idx + 1}
                      </span>
                    )}
                  </div>
                  <span className="text-xs font-semibold block">{step.label}</span>
                  <span className="text-[10px] block opacity-80">
                    {step.completed ? 'Completed' : 'Pending'}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Action Operations Bar */}
          <div className="pt-6 border-t border-[#E5E7EB] flex flex-wrap items-center gap-3">
            {isPending && (
              <>
                <button
                  type="button"
                  onClick={() => openActionModal('verify')}
                  className="px-4 py-2 rounded-md bg-[#1D4ED8] hover:bg-blue-800 text-xs font-semibold text-white transition-colors shadow-xs"
                >
                  Verify &amp; Dispatch Team
                </button>
                <button
                  type="button"
                  onClick={() => openActionModal('reject')}
                  className="px-3.5 py-2 rounded-md border border-red-200 bg-red-50 hover:bg-red-100 text-xs font-semibold text-[#DC2626] transition-colors"
                >
                  Reject Incident
                </button>
              </>
            )}

            {isActive && (
              <button
                type="button"
                onClick={() => openActionModal('resolve')}
                className="px-4 py-2 rounded-md bg-[#059669] hover:bg-emerald-700 text-xs font-semibold text-white transition-colors shadow-xs"
              >
                Mark Incident as Resolved
              </button>
            )}

            {isResolved && (
              <div className="flex items-center gap-2 text-xs font-medium text-[#059669] bg-emerald-50 px-3 py-1.5 rounded-md border border-emerald-200">
                <CheckCircle2 className="w-4 h-4" />
                <span>This incident has been resolved and closed.</span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Lifecycle Action Modal */}
      <LifecycleActionModal
        isOpen={modalState.isOpen}
        action={modalState.action}
        incident={incident}
        isLoading={modalState.isProcessing}
        onConfirm={handleModalConfirm}
        onCancel={closeModal}
      />
    </div>
  );
};

export default AuthorityIncidentDetailsPage;

