import React, { useState } from 'react';
import {
  Cpu,
  RefreshCw,
  AlertTriangle,
  CheckCircle2,
  Info,
  Server,
  Activity,
} from 'lucide-react';

const SENSOR_DATA = [
  {
    id: 'SM-001',
    type: 'Smoke Sensor (MQ-2)',
    location: 'College Block A - Level 2',
    reading: '650 ppm',
    threshold: '500 ppm',
    status: 'ALERT',
    lastUpdated: '20 Aug 2026, 11:05 AM',
    controller: 'ESP32 Node 1',
  },
  {
    id: 'WATER-002',
    type: 'Water Level Sensor (Ultrasonic)',
    location: 'Campus Gate & Drainage Channel',
    reading: '40 cm',
    threshold: '100 cm',
    status: 'NORMAL',
    lastUpdated: '20 Aug 2026, 11:04 AM',
    controller: 'ESP32 Node 2',
  },
  {
    id: 'FLM-003',
    type: 'Flame Sensor (IR Optical)',
    location: 'Chemistry Lab & Chemical Store',
    reading: '0.02 lux',
    threshold: '0.80 lux',
    status: 'NORMAL',
    lastUpdated: '20 Aug 2026, 11:05 AM',
    controller: 'ESP32 Node 3',
  },
  {
    id: 'TEMP-004',
    type: 'Temperature Sensor (DHT22)',
    location: 'Server Room & Power Substation',
    reading: '28°C',
    threshold: '45°C',
    status: 'NORMAL',
    lastUpdated: '20 Aug 2026, 11:03 AM',
    controller: 'ESP32 Node 4',
  },
  {
    id: 'GAS-005',
    type: 'Gas Leak Sensor (MQ-5)',
    location: 'Cafeteria Kitchen Gas Line',
    reading: '180 ppm',
    threshold: '400 ppm',
    status: 'NORMAL',
    lastUpdated: '20 Aug 2026, 11:02 AM',
    controller: 'ESP32 Node 5',
  },
];

const SensorMonitoringPage = () => {
  const [sensors] = useState(SENSOR_DATA);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const handleRefresh = () => {
    setIsRefreshing(true);
    setTimeout(() => setIsRefreshing(false), 600);
  };

  return (
    <div className="space-y-6 font-sans">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-[#E5E7EB]">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-[#111827]">
            IoT Sensors
          </h1>
          <p className="text-xs sm:text-sm text-[#64748B] mt-0.5">
            Sensor registry and threshold monitoring for incident detection.
          </p>
        </div>

        <button
          type="button"
          onClick={handleRefresh}
          disabled={isRefreshing}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md border border-[#E5E7EB] bg-white hover:bg-slate-50 text-xs font-medium text-[#111827] transition-colors"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin' : ''}`} />
          <span>{isRefreshing ? 'Polling Sensors...' : 'Poll Sensors'}</span>
        </button>
      </div>

      <div className="bg-white border border-[#E5E7EB] rounded-lg p-5 shadow-xs space-y-3">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded bg-blue-50 text-[#1D4ED8]">
            <Cpu className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-[#111827]">
              Sensor Monitoring
            </h2>
            <p className="text-xs text-[#64748B]">
              Registered sensor information and configured alert thresholds.
            </p>
          </div>
        </div>

        <div className="bg-[#F5F7FA] p-3.5 rounded-md border border-[#E5E7EB] text-xs text-[#64748B] leading-relaxed">
          <p>Sensor readings shown here represent the registered monitoring configuration available to this application. Alerts should be verified by an authority before operational action is taken.</p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
          <div className="p-2.5 rounded bg-[#F5F7FA] border border-[#E5E7EB]">
            <span className="text-[#64748B] block text-[10px]">REGISTERED SENSORS</span>
            <strong className="text-[#111827]">{sensors.length} sensor nodes</strong>
          </div>
          <div className="p-2.5 rounded bg-[#F5F7FA] border border-[#E5E7EB]">
            <span className="text-[#64748B] block text-[10px]">ALERTS</span>
            <strong className="text-[#DC2626]">{sensors.filter((sensor) => sensor.status === 'ALERT').length} require review</strong>
          </div>
          <div className="p-2.5 rounded bg-[#F5F7FA] border border-[#E5E7EB]">
            <span className="text-[#64748B] block text-[10px]">STATUS</span>
            <strong className="text-[#059669]">{sensors.filter((sensor) => sensor.status === 'NORMAL').length} operating normally</strong>
          </div>
          <div className="p-2.5 rounded bg-[#F5F7FA] border border-[#E5E7EB]">
            <span className="text-[#64748B] block text-[10px]">REVIEW PROCESS</span>
            <strong className="text-[#111827]">Authority verification</strong>
          </div>
        </div>
      </div>

      {/* 9. Professional IoT Sensor Table */}
      <div className="bg-white border border-[#E5E7EB] rounded-lg shadow-xs overflow-hidden">
        <div className="p-4 border-b border-[#E5E7EB]">
          <h2 className="text-sm font-bold text-[#111827]">
            Configured IoT Sensor Nodes
          </h2>
          <p className="text-xs text-[#64748B]">
            Real-time status, readings, and trigger thresholds
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-[#111827]">
            <thead className="border-b border-[#E5E7EB] bg-[#F5F7FA] text-[11px] font-semibold uppercase text-[#64748B]">
              <tr>
                <th className="py-2.5 px-4">Sensor ID</th>
                <th className="py-2.5 px-4">Sensor Type</th>
                <th className="py-2.5 px-4">Location</th>
                <th className="py-2.5 px-4">Reading</th>
                <th className="py-2.5 px-4">Threshold</th>
                <th className="py-2.5 px-4">Status</th>
                <th className="py-2.5 px-4">Last Updated</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#E5E7EB]">
              {sensors.map((sensor) => {
                const isAlert = sensor.status === 'ALERT';
                return (
                  <tr key={sensor.id} className="hover:bg-slate-50 transition-colors">
                    {/* Sensor ID */}
                    <td className="py-3 px-4 font-semibold text-[#111827]">
                      {sensor.id}
                    </td>

                    {/* Sensor Type */}
                    <td className="py-3 px-4 font-medium text-[#111827]">
                      {sensor.type}
                    </td>

                    {/* Location */}
                    <td className="py-3 px-4 text-[#64748B]">
                      {sensor.location}
                    </td>

                    {/* Reading */}
                    <td className={`py-3 px-4 font-semibold ${isAlert ? 'text-[#DC2626]' : 'text-[#111827]'}`}>
                      {sensor.reading}
                    </td>

                    {/* Threshold */}
                    <td className="py-3 px-4 text-[#64748B]">
                      {sensor.threshold}
                    </td>

                    {/* Status */}
                    <td className="py-3 px-4">
                      {isAlert ? (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-bold bg-red-50 text-[#DC2626] border border-red-200">
                          <AlertTriangle className="w-3 h-3" />
                          ALERT
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-bold bg-emerald-50 text-[#059669] border border-emerald-200">
                          <CheckCircle2 className="w-3 h-3" />
                          NORMAL
                        </span>
                      )}
                    </td>

                    {/* Last Updated */}
                    <td className="py-3 px-4 text-[#64748B]">
                      {sensor.lastUpdated}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default SensorMonitoringPage;
