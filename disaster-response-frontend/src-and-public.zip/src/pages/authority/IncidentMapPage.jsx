import React, { useState, useEffect, useCallback } from 'react';
import { Map, RefreshCw, Filter } from 'lucide-react';
import incidentService from '../../services/incidentService';
import IncidentMap from '../../components/maps/IncidentMap';
import LoadingSpinner from '../../components/common/LoadingSpinner';
import ErrorAlert from '../../components/common/ErrorAlert';
import { DISASTER_TYPES, INCIDENT_STATUSES } from '../../constants/incidentConstants';

const IncidentMapPage = () => {
  const [incidents, setIncidents] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isRetrying, setIsRetrying] = useState(false);

  const [selectedType, setSelectedType] = useState('All');
  const [selectedStatus, setSelectedStatus] = useState('All');

  const fetchIncidents = useCallback(async () => {
    try {
      setError(null);
      const data = await incidentService.getIncidents();
      setIncidents(Array.isArray(data) ? data : []);
    } catch (err) {
      console.error('Error fetching incidents for map:', err);
      setError(err.message || 'Unable to connect to incident server.');
    } finally {
      setIsLoading(false);
      setIsRetrying(false);
    }
  }, []);

  useEffect(() => {
    fetchIncidents();
  }, [fetchIncidents]);

  const filteredIncidents = incidents.filter((inc) => {
    if (selectedType !== 'All') {
      if ((inc.disasterType || '').trim().toLowerCase() !== selectedType.toLowerCase()) return false;
    }
    if (selectedStatus !== 'All') {
      if ((inc.status || '').trim().toLowerCase() !== selectedStatus.toLowerCase()) return false;
    }
    return true;
  });

  return (
    <div className="space-y-6 font-sans">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-[#E5E7EB]">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-[#111827]">
            Incident Map
          </h1>
          <p className="text-xs sm:text-sm text-[#64748B] mt-0.5">
            Geographic view of reported incidents, active responses, and verified emergency zones.
          </p>
        </div>

        <button
          type="button"
          onClick={() => {
            setIsRetrying(true);
            fetchIncidents();
          }}
          disabled={isLoading || isRetrying}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md border border-[#E5E7EB] bg-white hover:bg-slate-50 text-xs font-semibold text-[#111827] transition-colors"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isRetrying ? 'animate-spin' : ''}`} />
          <span>{isRetrying ? 'Syncing...' : 'Sync Map'}</span>
        </button>
      </div>

      {error && (
        <ErrorAlert
          title="Map Feed Error"
          message={error}
          onRetry={fetchIncidents}
          isRetrying={isRetrying}
        />
      )}

      {/* Map Filter Controls */}
      <div className="flex flex-wrap items-center gap-3 p-3.5 rounded-lg border border-[#E5E7EB] bg-white shadow-xs">
        <div className="flex items-center gap-1.5 text-xs text-[#64748B] font-medium">
          <Filter className="w-3.5 h-3.5" />
          <span>Filter:</span>
        </div>

        <select
          value={selectedType}
          onChange={(e) => setSelectedType(e.target.value)}
          className="px-2.5 py-1 rounded-md border border-[#E5E7EB] bg-white text-xs text-[#111827] focus:outline-none focus:ring-1 focus:ring-[#1D4ED8]"
        >
          <option value="All">All Disaster Types</option>
          {DISASTER_TYPES.map((t) => (
            <option key={t} value={t}>
              {t}
            </option>
          ))}
        </select>

        <select
          value={selectedStatus}
          onChange={(e) => setSelectedStatus(e.target.value)}
          className="px-2.5 py-1 rounded-md border border-[#E5E7EB] bg-white text-xs text-[#111827] focus:outline-none focus:ring-1 focus:ring-[#1D4ED8]"
        >
          <option value="All">All Statuses</option>
          {INCIDENT_STATUSES.map((s) => (
            <option key={s} value={s}>
              {s}
            </option>
          ))}
        </select>

        <div className="ml-auto text-xs text-[#64748B]">
          Showing {filteredIncidents.length} of {incidents.length} incidents
        </div>
      </div>

      {/* Interactive Map */}
      {isLoading ? (
        <LoadingSpinner message="Loading map markers..." />
      ) : (
        <div className="rounded-lg overflow-hidden border border-[#E5E7EB] shadow-xs">
          <IncidentMap incidents={filteredIncidents} />
        </div>
      )}
    </div>
  );
};

export default IncidentMapPage;

