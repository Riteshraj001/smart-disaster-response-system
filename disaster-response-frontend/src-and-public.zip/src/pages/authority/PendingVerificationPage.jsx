import React, { useState, useEffect, useCallback } from 'react';
import { Link } from 'react-router-dom';
import {
  Clock,
  MapPin,
  RefreshCw,
  Eye,
  CheckCircle2,
} from 'lucide-react';
import incidentService from '../../services/incidentService';
import { useNotification } from '../../context/NotificationContext';
import DisasterIcon from '../../components/common/DisasterIcon';
import SourceBadge from '../../components/common/SourceBadge';
import StatusBadge from '../../components/common/StatusBadge';
import SeverityBadge from '../../components/common/SeverityBadge';
import LifecycleActionModal from '../../components/common/LifecycleActionModal';
import LoadingSpinner from '../../components/common/LoadingSpinner';
import ErrorAlert from '../../components/common/ErrorAlert';
import EmptyState from '../../components/common/EmptyState';

const PendingVerificationPage = () => {
  const { showToast } = useNotification();
  const [pendingIncidents, setPendingIncidents] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isRetrying, setIsRetrying] = useState(false);

  // Modal State
  const [modalState, setModalState] = useState({
    isOpen: false,
    action: 'verify',
    incident: null,
    isProcessing: false,
  });

  const fetchPending = useCallback(async () => {
    try {
      setError(null);
      const allIncidents = await incidentService.getIncidents();
      const filtered = (Array.isArray(allIncidents) ? allIncidents : []).filter(
        (i) => (i.status || '').trim().toLowerCase() === 'pending'
      );
      setPendingIncidents(filtered);
    } catch (err) {
      console.error('Error fetching pending incidents:', err);
      setError(err.message || 'Unable to connect to incident server.');
    } finally {
      setIsLoading(false);
      setIsRetrying(false);
    }
  }, []);

  useEffect(() => {
    fetchPending();
  }, [fetchPending]);

  const openActionModal = (action, incident) => {
    setModalState({
      isOpen: true,
      action,
      incident,
      isProcessing: false,
    });
  };

  const closeModal = () => {
    if (!modalState.isProcessing) {
      setModalState({
        isOpen: false,
        action: 'verify',
        incident: null,
        isProcessing: false,
      });
    }
  };

  const handleModalConfirm = async (payload = {}) => {
    const { action, incident } = modalState;
    if (!incident) return;

    setModalState((prev) => ({ ...prev, isProcessing: true }));
    try {
      if (action === 'verify') {
        await incidentService.verifyAndActivate(incident.id, incident, payload);
        showToast(`Incident #${incident.id} verified and marked as Active.`, 'success');
        setPendingIncidents((prev) => prev.filter((i) => i.id !== incident.id));
      } else if (action === 'reject') {
        await incidentService.rejectIncident(incident.id, incident, payload.reason);
        showToast(`Incident #${incident.id} rejected.`, 'info');
        setPendingIncidents((prev) => prev.filter((i) => i.id !== incident.id));
      }
      closeModal();
    } catch (err) {
      console.error('Action error:', err);
      showToast(err.message || 'Failed to process action.', 'error');
      setModalState((prev) => ({ ...prev, isProcessing: false }));
    }
  };

  return (
    <div className="space-y-6 font-sans">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-[#E5E7EB]">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-[#111827]">
            Pending Verification
          </h1>
          <p className="text-xs sm:text-sm text-[#64748B] mt-0.5">
            Incoming citizen reports and automated triggers requiring review before responder dispatch.
          </p>
        </div>

        <button
          type="button"
          onClick={() => {
            setIsRetrying(true);
            fetchPending();
          }}
          disabled={isLoading || isRetrying}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md border border-[#E5E7EB] bg-white hover:bg-slate-50 text-xs font-semibold text-[#111827] transition-colors"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isRetrying ? 'animate-spin' : ''}`} />
          <span>{isRetrying ? 'Refreshing...' : 'Refresh'}</span>
        </button>
      </div>

      {error && (
        <ErrorAlert
          title="Connection Error"
          message={error}
          onRetry={fetchPending}
          isRetrying={isRetrying}
        />
      )}

      {isLoading ? (
        <LoadingSpinner message="Checking for pending incidents..." />
      ) : pendingIncidents.length === 0 ? (
        <EmptyState
          title="No Pending Incidents"
          description="All submitted reports have been reviewed and processed. No pending items in queue."
          actionText="View All Incidents"
          onAction={() => window.location.assign('/authority/incidents')}
        />
      ) : (
        <div className="space-y-4">
          <div className="text-xs text-[#64748B] font-medium">
            {pendingIncidents.length} incident(s) awaiting review
          </div>

          <div className="grid grid-cols-1 gap-3">
            {pendingIncidents.map((incident) => (
              <div
                key={incident.id}
                className="bg-white border border-[#E5E7EB] rounded-lg p-5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4"
              >
                <div className="space-y-2.5 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-[#111827]">
                      Incident #{incident.id}
                    </span>
                    <SourceBadge source={incident.source || 'MANUAL'} size="sm" />
                    <SeverityBadge severity={incident.severity || 'Medium'} size="sm" />
                    <StatusBadge status="Pending" size="sm" />
                  </div>

                  <div className="flex items-center gap-3">
                    <DisasterIcon type={incident.disasterType} showContainer size="sm" />
                    <div>
                      <h3 className="text-sm font-bold text-[#111827]">
                        {incident.disasterType}
                      </h3>
                      <p className="text-xs text-[#64748B] flex items-center gap-1 mt-0.5">
                        <MapPin className="w-3.5 h-3.5 shrink-0" />
                        <span>{incident.location}</span>
                      </p>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0 pt-3 md:pt-0 border-t md:border-t-0 border-[#E5E7EB]">
                  <Link
                    to={`/authority/incidents/${incident.id}`}
                    className="px-3 py-1.5 rounded-md border border-[#E5E7EB] bg-white hover:bg-slate-50 text-[#111827] text-xs font-semibold flex items-center gap-1 transition-colors"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>View</span>
                  </Link>

                  <button
                    type="button"
                    onClick={() => openActionModal('reject', incident)}
                    className="px-3 py-1.5 rounded-md border border-red-200 bg-red-50 hover:bg-red-100 text-xs font-semibold text-[#DC2626] transition-colors"
                  >
                    Reject
                  </button>

                  <button
                    type="button"
                    onClick={() => openActionModal('verify', incident)}
                    className="px-3.5 py-1.5 rounded-md bg-[#1D4ED8] hover:bg-blue-800 text-xs font-semibold text-white transition-colors shadow-xs"
                  >
                    Verify &amp; Dispatch
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <LifecycleActionModal
        isOpen={modalState.isOpen}
        action={modalState.action}
        incident={modalState.incident}
        isLoading={modalState.isProcessing}
        onConfirm={handleModalConfirm}
        onCancel={closeModal}
      />
    </div>
  );
};

export default PendingVerificationPage;

