import React, { useState, useEffect, useCallback } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  Layers,
  Flame,
  Clock,
  CheckCircle2,
  Cpu,
  User,
  Radio,
  RefreshCw,
  ArrowRight,
  MapPin,
  Calendar,
} from 'lucide-react';
import incidentService from '../../services/incidentService';
import { useNotification } from '../../context/NotificationContext';
import StatCard from '../../components/common/StatCard';
import SourceBadge from '../../components/common/SourceBadge';
import SeverityBadge from '../../components/common/SeverityBadge';
import StatusBadge from '../../components/common/StatusBadge';
import DisasterIcon from '../../components/common/DisasterIcon';
import ConfirmDialog from '../../components/common/ConfirmDialog';
import LoadingSpinner from '../../components/common/LoadingSpinner';
import ErrorAlert from '../../components/common/ErrorAlert';
import DisasterTypeChart from '../../components/dashboard/DisasterTypeChart';
import StatusBreakdownChart from '../../components/dashboard/StatusBreakdownChart';

const AuthorityDashboard = () => {
  const navigate = useNavigate();
  const { showToast } = useNotification();

  const [incidents, setIncidents] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isRetrying, setIsRetrying] = useState(false);
  const [incidentToDelete, setIncidentToDelete] = useState(null);
  const [isDeleting, setIsDeleting] = useState(false);

  const fetchIncidents = useCallback(async () => {
    try {
      setError(null);
      const data = await incidentService.getIncidents();
      setIncidents(Array.isArray(data) ? data : []);
    } catch (err) {
      console.error('Error fetching dashboard data:', err);
      setError(err.message || 'Unable to connect to emergency backend.');
    } finally {
      setIsLoading(false);
      setIsRetrying(false);
    }
  }, []);

  useEffect(() => {
    fetchIncidents();
  }, [fetchIncidents]);

  // Real statistics from backend
  const total = incidents.length;
  const pendingCount = incidents.filter(
    (i) => (i.status || '').toLowerCase() === 'pending'
  ).length;
  const activeCount = incidents.filter(
    (i) => (i.status || '').toLowerCase() === 'active'
  ).length;
  const resolvedCount = incidents.filter(
    (i) => (i.status || '').toLowerCase() === 'resolved'
  ).length;

  const recentIncidents = [...incidents]
    .sort((a, b) => (b.id || 0) - (a.id || 0))
    .slice(0, 6);

  const handleDeleteConfirm = async () => {
    if (!incidentToDelete) return;
    setIsDeleting(true);
    try {
      await incidentService.deleteIncident(incidentToDelete.id);
      showToast(`Incident #${incidentToDelete.id} deleted successfully.`, 'success');
      setIncidents((prev) => prev.filter((i) => i.id !== incidentToDelete.id));
      setIncidentToDelete(null);
    } catch (err) {
      console.error('Delete error:', err);
      showToast(err.message || 'Failed to delete incident.', 'error');
    } finally {
      setIsDeleting(false);
    }
  };

  const formatReportedDate = (dateStr) => {
    if (!dateStr) return 'Recently';
    try {
      const d = new Date(dateStr);
      if (isNaN(d.getTime())) return dateStr;
      return d.toLocaleString('en-GB', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      });
    } catch {
      return dateStr;
    }
  };

  return (
    <div className="space-y-6 font-sans">
      {/* 6. Professional Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-[#E5E7EB]">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-[#111827]">
            Authority Dashboard
          </h1>
          <p className="text-xs sm:text-sm text-[#64748B] mt-0.5">
            Monitor, verify and coordinate emergency incidents.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            type="button"
            onClick={() => {
              setIsRetrying(true);
              fetchIncidents();
            }}
            disabled={isLoading || isRetrying}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md border border-[#E5E7EB] bg-white text-xs font-medium text-[#111827] hover:bg-slate-50 transition-colors"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isRetrying ? 'animate-spin' : ''}`} />
            <span>{isRetrying ? 'Refreshing...' : 'Refresh Data'}</span>
          </button>

          <Link
            to="/authority/incidents"
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-md bg-[#1D4ED8] hover:bg-blue-800 text-xs font-semibold text-white transition-colors shadow-xs"
          >
            <Radio className="w-3.5 h-3.5" />
            <span>All Incidents</span>
          </Link>
        </div>
      </div>

      {error && (
        <ErrorAlert
          title="Backend Service Notice"
          message={error}
          onRetry={fetchIncidents}
          isRetrying={isRetrying}
        />
      )}

      {isLoading ? (
        <LoadingSpinner message="Loading dashboard statistics..." />
      ) : (
        <>
          {/* Statistics Grid: Total Incidents, Pending, Active, Resolved */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <StatCard
              title="Total Incidents"
              value={total}
              icon={Layers}
              variant="default"
              subtitle="All registered records"
              onClick={() => navigate('/authority/incidents')}
            />

            <StatCard
              title="Pending"
              value={pendingCount}
              icon={Clock}
              variant="pending"
              subtitle="Awaiting verification"
              badgeText="VERIFICATION"
              onClick={() => navigate('/authority/verification')}
            />

            <StatCard
              title="Active"
              value={activeCount}
              icon={Flame}
              variant="active"
              subtitle="Response in progress"
              badgeText="IN PROGRESS"
              onClick={() => navigate('/authority/incidents?status=Active')}
            />

            <StatCard
              title="Resolved"
              value={resolvedCount}
              icon={CheckCircle2}
              variant="resolved"
              subtitle="Completed operations"
              onClick={() => navigate('/authority/incidents?status=Resolved')}
            />
          </div>

          {/* Operational Status Breakdown & Type Distribution Charts */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <DisasterTypeChart incidents={incidents} />
            <StatusBreakdownChart incidents={incidents} />
          </div>

          {/* Recent Incidents Table */}
          <div className="bg-white border border-[#E5E7EB] rounded-lg shadow-xs overflow-hidden">
            <div className="p-4 border-b border-[#E5E7EB] flex items-center justify-between">
              <div>
                <h2 className="text-sm font-bold text-[#111827]">
                  Recent Incidents
                </h2>
                <p className="text-xs text-[#64748B]">
                  Recently reported emergencies and sensor detections
                </p>
              </div>

              <Link
                to="/authority/incidents"
                className="inline-flex items-center gap-1 text-xs font-semibold text-[#1D4ED8] hover:text-blue-800 transition-colors"
              >
                <span>View All ({total})</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </Link>
            </div>

            {recentIncidents.length === 0 ? (
              <div className="p-8 text-center text-sm text-[#64748B]">
                No incidents recorded in the system.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-[#111827]">
                  <thead className="border-b border-[#E5E7EB] bg-[#F5F7FA] text-[11px] font-semibold uppercase text-[#64748B]">
                    <tr>
                      <th className="py-2.5 px-4">ID</th>
                      <th className="py-2.5 px-4">Disaster Type</th>
                      <th className="py-2.5 px-4">Location</th>
                      <th className="py-2.5 px-4">Source</th>
                      <th className="py-2.5 px-4">Severity</th>
                      <th className="py-2.5 px-4">Status</th>
                      <th className="py-2.5 px-4">Reported At</th>
                      <th className="py-2.5 px-4 text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#E5E7EB]">
                    {recentIncidents.map((inc) => (
                      <tr key={inc.id} className="hover:bg-slate-50 transition-colors">
                        <td className="py-3 px-4 font-semibold text-[#111827]">
                          #{inc.id}
                        </td>
                        <td className="py-3 px-4">
                          <div className="flex items-center gap-2">
                            <DisasterIcon type={inc.disasterType} showContainer size="sm" />
                            <span className="font-medium text-[#111827]">{inc.disasterType}</span>
                          </div>
                        </td>
                        <td className="py-3 px-4 text-[#64748B]">
                          <span className="flex items-center gap-1">
                            <MapPin className="w-3.5 h-3.5 text-[#64748B] shrink-0" />
                            {inc.location}
                          </span>
                        </td>
                        <td className="py-3 px-4">
                          <SourceBadge source={inc.source || 'MANUAL'} size="sm" />
                        </td>
                        <td className="py-3 px-4">
                          <SeverityBadge severity={inc.severity || 'Medium'} size="sm" />
                        </td>
                        <td className="py-3 px-4">
                          <StatusBadge status={inc.status} size="sm" />
                        </td>
                        <td className="py-3 px-4 text-[#64748B]">
                          <span className="flex items-center gap-1">
                            <Calendar className="w-3 h-3 text-[#64748B]" />
                            {formatReportedDate(inc.createdAt || inc.reportedAt || inc.timestamp)}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-right">
                          <Link
                            to={`/authority/incidents/${inc.id}`}
                            className="px-2.5 py-1 rounded border border-[#E5E7EB] bg-white hover:bg-slate-50 text-[#1D4ED8] hover:text-blue-800 text-xs font-semibold transition-colors"
                          >
                            View Record
                          </Link>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </>
      )}

      <ConfirmDialog
        isOpen={Boolean(incidentToDelete)}
        incident={incidentToDelete}
        onConfirm={handleDeleteConfirm}
        onCancel={() => setIncidentToDelete(null)}
        isLoading={isDeleting}
      />
    </div>
  );
};

export default AuthorityDashboard;
