import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import {
  Radio,
  PlusCircle,
  RefreshCw,
  Search,
  Eye,
  Trash2,
  MapPin,
  CheckCircle2,
  Ban,
  Check,
} from 'lucide-react';
import incidentService from '../../services/incidentService';
import { useNotification } from '../../context/NotificationContext';
import {
  DISASTER_TYPES,
  INCIDENT_STATUSES,
  SEVERITY_LEVELS,
} from '../../constants/incidentConstants';
import SourceBadge from '../../components/common/SourceBadge';
import SeverityBadge from '../../components/common/SeverityBadge';
import StatusBadge from '../../components/common/StatusBadge';
import DisasterIcon from '../../components/common/DisasterIcon';
import LifecycleActionModal from '../../components/common/LifecycleActionModal';
import LoadingSpinner from '../../components/common/LoadingSpinner';
import ErrorAlert from '../../components/common/ErrorAlert';
import EmptyState from '../../components/common/EmptyState';

const LiveIncidentsPage = () => {
  const [searchParams] = useSearchParams();
  const { showToast } = useNotification();

  const [incidents, setIncidents] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isRetrying, setIsRetrying] = useState(false);

  // Filters
  const [searchTerm, setSearchTerm] = useState(searchParams.get('q') || '');
  const [selectedType, setSelectedType] = useState(searchParams.get('type') || 'All');
  const [selectedStatus, setSelectedStatus] = useState(searchParams.get('status') || 'All');
  const [selectedSeverity, setSelectedSeverity] = useState(searchParams.get('severity') || 'All');

  // Lifecycle confirmation modal state
  const [modalState, setModalState] = useState({
    isOpen: false,
    action: 'verify', // 'verify' | 'reject' | 'resolve' | 'delete'
    incident: null,
    isProcessing: false,
  });

  const fetchIncidents = useCallback(async () => {
    try {
      setError(null);
      const data = await incidentService.getIncidents();
      setIncidents(Array.isArray(data) ? data : []);
    } catch (err) {
      console.error('Error loading incidents:', err);
      setError(err.message || 'Unable to connect to disaster database.');
    } finally {
      setIsLoading(false);
      setIsRetrying(false);
    }
  }, []);

  useEffect(() => {
    fetchIncidents();
  }, [fetchIncidents]);

  // Filtering
  const filteredIncidents = useMemo(() => {
    return incidents.filter((incident) => {
      if (searchTerm.trim()) {
        const q = searchTerm.trim().toLowerCase();
        const matchesType = (incident.disasterType || '').toLowerCase().includes(q);
        const matchesLocation = (incident.location || '').toLowerCase().includes(q);
        const matchesStatus = (incident.status || '').toLowerCase().includes(q);
        const matchesId = String(incident.id || '').toLowerCase().includes(q);
        if (!matchesType && !matchesLocation && !matchesStatus && !matchesId) return false;
      }

      if (selectedType !== 'All') {
        if ((incident.disasterType || '').trim().toLowerCase() !== selectedType.toLowerCase()) {
          return false;
        }
      }

      if (selectedStatus !== 'All') {
        if ((incident.status || '').trim().toLowerCase() !== selectedStatus.toLowerCase()) {
          return false;
        }
      }

      if (selectedSeverity !== 'All') {
        if ((incident.severity || '').trim().toLowerCase() !== selectedSeverity.toLowerCase()) {
          return false;
        }
      }

      return true;
    });
  }, [incidents, searchTerm, selectedType, selectedStatus, selectedSeverity]);

  // Open modal handlers
  const openActionModal = (action, incident) => {
    setModalState({
      isOpen: true,
      action,
      incident,
      isProcessing: false,
    });
  };

  const closeModal = () => {
    if (!modalState.isProcessing) {
      setModalState({
        isOpen: false,
        action: 'verify',
        incident: null,
        isProcessing: false,
      });
    }
  };

  // Handle modal submit
  const handleModalConfirm = async (payload = {}) => {
    const { action, incident } = modalState;
    if (!incident) return;

    setModalState((prev) => ({ ...prev, isProcessing: true }));

    try {
      if (action === 'verify') {
        const updated = await incidentService.verifyAndActivate(incident.id, incident, payload);
        showToast(`Incident #${incident.id} verified and activated.`, 'success');
        setIncidents((prev) => prev.map((item) => (item.id === incident.id ? updated : item)));
      } else if (action === 'reject') {
        const updated = await incidentService.rejectIncident(incident.id, incident, payload.reason);
        showToast(`Incident #${incident.id} rejected and closed.`, 'info');
        setIncidents((prev) => prev.map((item) => (item.id === incident.id ? updated : item)));
      } else if (action === 'resolve') {
        const updated = await incidentService.resolveIncident(incident.id, incident, payload.notes);
        showToast(`Incident #${incident.id} marked as Resolved.`, 'success');
        setIncidents((prev) => prev.map((item) => (item.id === incident.id ? updated : item)));
      } else if (action === 'delete') {
        await incidentService.deleteIncident(incident.id);
        showToast(`Incident #${incident.id} deleted successfully.`, 'success');
        setIncidents((prev) => prev.filter((item) => item.id !== incident.id));
      }
      closeModal();
    } catch (err) {
      console.error(`Error during action [${action}]:`, err);
      showToast(err.message || 'Action failed to execute on server.', 'error');
      setModalState((prev) => ({ ...prev, isProcessing: false }));
    }
  };

  return (
    <div className="space-y-6 font-sans">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-[#E5E7EB]">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-[#111827]">
            Incidents
          </h1>
          <p className="text-xs sm:text-sm text-[#64748B] mt-0.5">
            Manage reported emergencies, verify incoming alerts, and track status.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            type="button"
            onClick={() => {
              setIsRetrying(true);
              fetchIncidents();
            }}
            disabled={isLoading || isRetrying}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md border border-[#E5E7EB] bg-white text-xs font-medium text-[#111827] hover:bg-slate-50 transition-colors"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isRetrying ? 'animate-spin' : ''}`} />
            <span>{isRetrying ? 'Refreshing...' : 'Refresh'}</span>
          </button>

          <Link
            to="/authority/incidents/create"
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-md bg-[#1D4ED8] hover:bg-blue-800 text-xs font-semibold text-white transition-colors shadow-xs"
          >
            <PlusCircle className="w-3.5 h-3.5" />
            <span>New Incident</span>
          </Link>
        </div>
      </div>

      {error && (
        <ErrorAlert
          title="Service Unavailable"
          message={error}
          onRetry={fetchIncidents}
          isRetrying={isRetrying}
        />
      )}

      {/* Filter Bar */}
      <div className="rounded-lg border border-[#E5E7EB] bg-white p-3.5 shadow-xs">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
          {/* Search Box */}
          <div className="relative">
            <Search className="w-4 h-4 text-[#64748B] absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search by ID, type, location..."
              className="w-full pl-9 pr-3 py-1.5 rounded-md border border-[#E5E7EB] bg-white text-xs text-[#111827] placeholder-[#64748B] focus:border-[#1D4ED8] focus:outline-none"
            />
          </div>

          {/* Disaster Type Filter */}
          <select
            value={selectedType}
            onChange={(e) => setSelectedType(e.target.value)}
            className="w-full px-3 py-1.5 rounded-md border border-[#E5E7EB] bg-white text-xs text-[#111827] focus:border-[#1D4ED8] focus:outline-none"
          >
            <option value="All">All Disaster Types</option>
            {DISASTER_TYPES.map((t) => (
              <option key={t} value={t}>
                {t}
              </option>
            ))}
          </select>

          {/* Status Filter */}
          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="w-full px-3 py-1.5 rounded-md border border-[#E5E7EB] bg-white text-xs text-[#111827] focus:border-[#1D4ED8] focus:outline-none"
          >
            <option value="All">All Statuses</option>
            {INCIDENT_STATUSES.map((s) => (
              <option key={s} value={s}>
                {s === 'Pending' ? 'Pending' : s === 'Active' ? 'Active' : 'Resolved'}
              </option>
            ))}
          </select>

          {/* Severity Filter */}
          <select
            value={selectedSeverity}
            onChange={(e) => setSelectedSeverity(e.target.value)}
            className="w-full px-3 py-1.5 rounded-md border border-[#E5E7EB] bg-white text-xs text-[#111827] focus:border-[#1D4ED8] focus:outline-none"
          >
            <option value="All">All Severity Levels</option>
            {SEVERITY_LEVELS.map((sev) => (
              <option key={sev} value={sev}>
                {sev} Severity
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Main Table */}
      {isLoading ? (
        <LoadingSpinner message="Loading incident records..." />
      ) : filteredIncidents.length === 0 ? (
        <EmptyState
          title="No Matching Incidents"
          description="No incidents matched your search criteria. Adjust filters or register a new emergency entry."
          actionText="Clear Filters"
          onAction={() => {
            setSearchTerm('');
            setSelectedType('All');
            setSelectedStatus('All');
            setSelectedSeverity('All');
          }}
        />
      ) : (
        <div className="bg-white border border-[#E5E7EB] rounded-lg shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-[#111827]">
              <thead className="border-b border-[#E5E7EB] bg-[#F5F7FA] text-[11px] font-semibold uppercase text-[#64748B]">
                <tr>
                  <th className="py-2.5 px-4">ID</th>
                  <th className="py-2.5 px-4">Disaster Type</th>
                  <th className="py-2.5 px-4">Location</th>
                  <th className="py-2.5 px-4">Source</th>
                  <th className="py-2.5 px-4">Severity</th>
                  <th className="py-2.5 px-4">Status</th>
                  <th className="py-2.5 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#E5E7EB]">
                {filteredIncidents.map((incident) => {
                  const st = (incident.status || 'Pending').trim().toLowerCase();
                  const isPendingRow = st === 'pending';
                  const isActiveRow = st === 'active';
                  const isResolvedRow = st === 'resolved';

                  return (
                    <tr key={incident.id} className="hover:bg-slate-50 transition-colors">
                      {/* ID */}
                      <td className="py-3 px-4 font-semibold text-[#111827]">
                        #{incident.id}
                      </td>

                      {/* Disaster */}
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2">
                          <DisasterIcon type={incident.disasterType} showContainer size="sm" />
                          <span className="font-medium text-[#111827]">{incident.disasterType}</span>
                        </div>
                      </td>

                      {/* Location */}
                      <td className="py-3 px-4 text-[#64748B]">
                        <span className="flex items-center gap-1 truncate max-w-[220px]" title={incident.location}>
                          <MapPin className="w-3.5 h-3.5 text-[#64748B] shrink-0" />
                          <span className="truncate">{incident.location}</span>
                        </span>
                      </td>

                      {/* Source */}
                      <td className="py-3 px-4">
                        <SourceBadge source={incident.source || 'MANUAL'} size="sm" />
                      </td>

                      {/* Severity */}
                      <td className="py-3 px-4">
                        <SeverityBadge severity={incident.severity || 'Medium'} size="sm" />
                      </td>

                      {/* Status */}
                      <td className="py-3 px-4">
                        <StatusBadge status={incident.status} size="sm" />
                      </td>

                      {/* Status-Dependent Action Buttons */}
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {/* PENDING: Verify, Reject */}
                          {isPendingRow && (
                            <>
                              <button
                                type="button"
                                onClick={() => openActionModal('verify', incident)}
                                className="px-2.5 py-1 rounded bg-[#1D4ED8] hover:bg-blue-800 text-[11px] font-semibold text-white transition-colors"
                                title="Verify incident and activate response"
                              >
                                Verify
                              </button>

                              <button
                                type="button"
                                onClick={() => openActionModal('reject', incident)}
                                className="px-2 py-1 rounded border border-red-200 bg-red-50 hover:bg-red-100 text-[11px] font-semibold text-[#DC2626] transition-colors"
                                title="Reject False Alarm"
                              >
                                Reject
                              </button>
                            </>
                          )}

                          {/* ACTIVE: Resolve */}
                          {isActiveRow && (
                            <button
                              type="button"
                              onClick={() => openActionModal('resolve', incident)}
                              className="px-2.5 py-1 rounded bg-[#059669] hover:bg-emerald-700 text-[11px] font-semibold text-white transition-colors"
                              title="Mark incident as resolved"
                            >
                              Resolve
                            </button>
                          )}

                          {/* RESOLVED label */}
                          {isResolvedRow && (
                            <span className="text-[10px] text-[#059669] font-medium px-1.5 py-0.5 rounded bg-emerald-50 border border-emerald-200">
                              Resolved
                            </span>
                          )}

                          {/* View Button */}
                          <Link
                            to={`/authority/incidents/${incident.id}`}
                            className="px-2 py-1 rounded border border-[#E5E7EB] bg-white hover:bg-slate-50 text-[11px] font-medium text-[#111827] transition-colors"
                            title="View Incident Record"
                          >
                            View
                          </Link>

                          {/* Delete option */}
                          <button
                            type="button"
                            onClick={() => openActionModal('delete', incident)}
                            className="p-1 rounded text-[#64748B] hover:text-[#DC2626] hover:bg-red-50 transition-colors"
                            title="Delete Incident"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Confirmation Modal for Lifecycle Actions */}
      <LifecycleActionModal
        isOpen={modalState.isOpen}
        action={modalState.action}
        incident={modalState.incident}
        isLoading={modalState.isProcessing}
        onConfirm={handleModalConfirm}
        onCancel={closeModal}
      />
    </div>
  );
};

export default LiveIncidentsPage;

