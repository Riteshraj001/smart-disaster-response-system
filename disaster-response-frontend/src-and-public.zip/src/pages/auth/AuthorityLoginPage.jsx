import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Shield, Lock, Mail, ArrowRight, Building } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

const AuthorityLoginPage = () => {
  const navigate = useNavigate();
  const [email, setEmail] = useState('commander@disaster-ops.gov');
  const [password, setPassword] = useState('authoritypass456');
  const [stationCode, setStationCode] = useState('HQ-NORTH-ZONE');
  const [rememberMe, setRememberMe] = useState(true);
  const { signIn } = useAuth();

  const handleSubmit = (e) => {
    e.preventDefault();
    signIn({ role: 'authority', name: email.split('@')[0], rememberMe });
    navigate('/authority', { replace: true });
  };

  return (
    <div className="min-h-screen bg-[#F5F7FA] text-[#111827] flex flex-col justify-center items-center p-4 sm:p-6 font-sans">
      <div className="w-full max-w-md space-y-6">
        {/* Header Branding */}
        <div className="text-center space-y-2">
          <Link to="/" className="inline-flex items-center gap-2">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-[#1D4ED8] text-white">
              <Shield className="w-5 h-5" />
            </div>
            <div className="text-left">
              <span className="text-base font-bold text-[#111827] block leading-tight">
                Disaster Response Portal
              </span>
              <span className="text-[11px] text-[#64748B]">Authority &amp; Response Console</span>
            </div>
          </Link>
          <h1 className="text-xl font-bold text-[#111827] pt-2">
            Authority Personnel Sign In
          </h1>
          <p className="text-xs text-[#64748B]">
            Authorized access for emergency responders and incident commanders.
          </p>
        </div>

        {/* Form */}
        <form
          onSubmit={handleSubmit}
          className="bg-white border border-[#E5E7EB] rounded-lg p-6 sm:p-8 shadow-xs space-y-4"
        >
          {/* Station Code */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-[#111827] flex items-center gap-1.5">
              <Building className="w-3.5 h-3.5 text-[#64748B]" />
              <span>Station / Hub Identifier</span>
            </label>
            <input
              type="text"
              value={stationCode}
              onChange={(e) => setStationCode(e.target.value)}
              required
              className="w-full rounded-md border border-[#E5E7EB] bg-white px-3 py-2 text-xs text-[#111827] placeholder-[#64748B] focus:outline-none focus:ring-1 focus:ring-[#1D4ED8]"
            />
          </div>

          {/* Email Field */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-[#111827] flex items-center gap-1.5">
              <Mail className="w-3.5 h-3.5 text-[#64748B]" />
              <span>Officer Email Address</span>
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              placeholder="officer@disaster-ops.gov"
              className="w-full rounded-md border border-[#E5E7EB] bg-white px-3 py-2 text-xs text-[#111827] placeholder-[#64748B] focus:outline-none focus:ring-1 focus:ring-[#1D4ED8]"
            />
          </div>

          {/* Password Field */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-[#111827] flex items-center gap-1.5">
                <Lock className="w-3.5 h-3.5 text-[#64748B]" />
                <span>Password</span>
              </label>
              <button
                type="button"
                onClick={() => alert('Password reset service will be available.')}
                className="text-[11px] text-[#1D4ED8] hover:underline"
              >
                Forgot?
              </button>
            </div>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              placeholder="••••••••"
              className="w-full rounded-md border border-[#E5E7EB] bg-white px-3 py-2 text-xs text-[#111827] placeholder-[#64748B] focus:outline-none focus:ring-1 focus:ring-[#1D4ED8]"
            />
          </div>

          <div className="flex items-center justify-between text-xs text-[#64748B]">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={rememberMe}
                onChange={(e) => setRememberMe(e.target.checked)}
                className="rounded border-[#E5E7EB] text-[#1D4ED8] focus:ring-[#1D4ED8]"
              />
              <span>Remember session</span>
            </label>
          </div>

          <button
            type="submit"
            className="w-full inline-flex items-center justify-center gap-2 py-2.5 px-4 rounded-md bg-[#1D4ED8] hover:bg-blue-800 text-xs font-semibold text-white shadow-xs transition-colors"
          >
            <span>Sign In to Authority Console</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

      </div>
    </div>
  );
};

export default AuthorityLoginPage;
