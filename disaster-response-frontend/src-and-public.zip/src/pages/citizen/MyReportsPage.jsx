import React, { useState, useEffect, useCallback } from 'react';
import { Link } from 'react-router-dom';
import {
  FileText,
  PlusCircle,
  MapPin,
  RefreshCw,
  Compass,
  CheckCircle2,
} from 'lucide-react';
import incidentService from '../../services/incidentService';
import StatusBadge from '../../components/common/StatusBadge';
import SeverityBadge from '../../components/common/SeverityBadge';
import SourceBadge from '../../components/common/SourceBadge';
import DisasterIcon from '../../components/common/DisasterIcon';
import EmptyState from '../../components/common/EmptyState';

const MyReportsPage = () => {
  const [reports, setReports] = useState([]);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const loadReports = useCallback(async () => {
    setIsRefreshing(true);
    const local = incidentService.getLocalCitizenReports();

    try {
      // Sync status with backend if available
      const backendIncidents = await incidentService.getIncidents();
      if (Array.isArray(backendIncidents)) {
        const synced = local.map((locRep) => {
          const matched = backendIncidents.find((b) => b.id === locRep.id);
          return matched
            ? { ...locRep, status: matched.status, severity: matched.severity || locRep.severity }
            : locRep;
        });
        setReports(synced);
      } else {
        setReports(local);
      }
    } catch {
      setReports(local);
    } finally {
      setIsRefreshing(false);
    }
  }, []);

  useEffect(() => {
    loadReports();
  }, [loadReports]);

  return (
    <div className="space-y-6 font-sans">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-[#E5E7EB]">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-[#111827]">
            My Submitted Reports
          </h1>
          <p className="text-xs sm:text-sm text-[#64748B] mt-0.5">
            Track verification, response dispatch, and resolution status of your reported incidents.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={loadReports}
            disabled={isRefreshing}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md border border-[#E5E7EB] bg-white hover:bg-slate-50 text-xs font-semibold text-[#111827] transition-colors"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin' : ''}`} />
            <span>Sync</span>
          </button>

          <Link
            to="/citizen/report"
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-md bg-[#1D4ED8] hover:bg-blue-800 text-xs font-semibold text-white shadow-xs transition-colors"
          >
            <PlusCircle className="w-3.5 h-3.5" />
            <span>New Report</span>
          </Link>
        </div>
      </div>

      {/* Reports List */}
      {reports.length === 0 ? (
        <EmptyState
          title="No Reports Submitted Yet"
          description="You haven't submitted any emergency reports from this browser. If you witness an incident, submit a report to alert authorities."
          actionText="Report an Incident"
          onAction={() => window.location.assign('/citizen/report')}
        />
      ) : (
        <div className="space-y-4">
          {reports.map((report) => {
            const statusLower = (report.status || '').toLowerCase();
            const stepIndex =
              statusLower === 'resolved' ? 3 : statusLower === 'active' ? 2 : 1;

            return (
              <div
                key={report.id}
                className="bg-white border border-[#E5E7EB] rounded-lg p-5 shadow-xs space-y-4"
              >
                {/* Header info */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#E5E7EB]">
                  <div className="flex items-center gap-3">
                    <DisasterIcon type={report.disasterType} showContainer size="sm" />
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-[#111827]">
                          Report #{report.id}
                        </span>
                        <SourceBadge source={report.source || 'MANUAL'} size="sm" />
                        <SeverityBadge severity={report.severity || 'Medium'} size="sm" />
                      </div>
                      <h3 className="text-sm font-semibold text-[#111827] mt-0.5">
                        {report.disasterType} Incident
                      </h3>
                    </div>
                  </div>

                  <div>
                    <StatusBadge status={report.status} size="sm" />
                  </div>
                </div>

                {/* Location & Details */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                  <div className="p-3 rounded-md border border-[#E5E7EB] bg-[#F5F7FA] space-y-1">
                    <span className="text-[#64748B] font-medium flex items-center gap-1">
                      <MapPin className="w-3.5 h-3.5" />
                      Location
                    </span>
                    <p className="text-xs font-semibold text-[#111827]">{report.location}</p>
                    {report.latitude && (
                      <p className="text-[11px] text-[#059669] flex items-center gap-1">
                        <Compass className="w-3 h-3" />
                        GPS: {report.latitude}, {report.longitude} (&plusmn;{report.accuracy}m)
                      </p>
                    )}
                  </div>

                  <div className="p-3 rounded-md border border-[#E5E7EB] bg-[#F5F7FA] space-y-1">
                    <span className="text-[#64748B] font-medium">Description</span>
                    <p className="text-xs text-[#111827]">
                      {report.description || 'No description provided.'}
                    </p>
                    <p className="text-[11px] text-[#64748B]">
                      People Affected: <strong className="text-[#111827]">{report.peopleAffected || 'None'}</strong>
                    </p>
                  </div>
                </div>

                {/* Timeline Progression */}
                <div className="pt-2">
                  <span className="text-xs font-semibold text-[#64748B] block mb-2">Resolution Progress</span>
                  <div className="grid grid-cols-3 gap-2 text-center text-xs">
                    <div
                      className={`p-2 rounded-md border ${
                        stepIndex >= 1
                          ? 'bg-blue-50 border-blue-200 text-[#1D4ED8] font-semibold'
                          : 'bg-[#F5F7FA] border-[#E5E7EB] text-[#64748B]'
                      }`}
                    >
                      1. Pending
                    </div>
                    <div
                      className={`p-2 rounded-md border ${
                        stepIndex >= 2
                          ? 'bg-amber-50 border-amber-200 text-[#D97706] font-semibold'
                          : 'bg-[#F5F7FA] border-[#E5E7EB] text-[#64748B]'
                      }`}
                    >
                      2. Verified / Dispatched
                    </div>
                    <div
                      className={`p-2 rounded-md border ${
                        stepIndex >= 3
                          ? 'bg-emerald-50 border-emerald-200 text-[#059669] font-semibold'
                          : 'bg-[#F5F7FA] border-[#E5E7EB] text-[#64748B]'
                      }`}
                    >
                      3. Resolved
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default MyReportsPage;

