import React, { useState, useEffect, useCallback } from 'react';
import { Link } from 'react-router-dom';
import {
  PlusCircle,
  PhoneCall,
  MapPin,
  AlertTriangle,
  FileText,
  ArrowRight,
  RefreshCw,
  CheckCircle2,
  Calendar,
} from 'lucide-react';
import incidentService from '../../services/incidentService';
import { EMERGENCY_HELPLINES } from '../../constants/incidentConstants';
import DisasterIcon from '../../components/common/DisasterIcon';
import StatusBadge from '../../components/common/StatusBadge';
import LoadingSpinner from '../../components/common/LoadingSpinner';
import ErrorAlert from '../../components/common/ErrorAlert';

const CitizenDashboard = () => {
  const [incidents, setIncidents] = useState([]);
  const [myReports, setMyReports] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const loadData = useCallback(async () => {
    try {
      setError(null);
      const data = await incidentService.getIncidents();
      setIncidents(Array.isArray(data) ? data : []);
      const local = incidentService.getLocalCitizenReports();
      setMyReports(local);
    } catch (err) {
      console.error('Failed to load community incidents:', err);
      setError(err.message || 'Unable to connect to emergency server.');
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  }, []);

  useEffect(() => {
    loadData();
  }, [loadData]);

  // Recent 4 community incidents
  const recentCommunityIncidents = [...incidents]
    .sort((a, b) => (b.id || 0) - (a.id || 0))
    .slice(0, 4);
  const reportSummary = {
    total: myReports.length,
    pending: myReports.filter((report) => (report.status || '').toLowerCase() === 'pending').length,
    active: myReports.filter((report) => (report.status || '').toLowerCase() === 'active').length,
    resolved: myReports.filter((report) => (report.status || '').toLowerCase() === 'resolved').length,
  };

  return (
    <div className="space-y-6 font-sans">
      <div className="flex flex-col gap-4 border-b border-[#E2E8F0] pb-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-xl font-bold text-[#172033]">Citizen Dashboard</h2>
          <p className="mt-1 text-sm text-[#64748B]">Review submitted reports and access emergency services.</p>
        </div>
        <Link to="/citizen/report" className="inline-flex items-center justify-center gap-2 rounded-md bg-[#2563EB] px-4 py-2 text-sm font-semibold text-white transition-colors hover:bg-blue-700"><PlusCircle className="h-4 w-4" />Report Incident</Link>
      </div>

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {[
          ['Total Reports', reportSummary.total, 'text-[#172033]'],
          ['Under Review', reportSummary.pending, 'text-[#D97706]'],
          ['In Progress', reportSummary.active, 'text-[#2563EB]'],
          ['Resolved', reportSummary.resolved, 'text-[#059669]'],
        ].map(([label, value, color]) => (
          <div key={label} className="rounded-lg border border-[#E2E8F0] bg-white p-4 shadow-[0_1px_3px_rgba(15,23,42,0.06)]">
            <p className="text-xs font-medium text-[#64748B]">{label}</p>
            <p className={`mt-2 text-2xl font-bold ${color}`}>{value}</p>
          </div>
        ))}
      </div>

      {/* Public Emergency Action Banner */}
      <div className="bg-white border border-[#E2E8F0] rounded-lg p-6 shadow-[0_1px_3px_rgba(15,23,42,0.06)]">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded bg-blue-50 text-[#1D4ED8] text-xs font-semibold">
              <span className="w-1.5 h-1.5 rounded-full bg-[#1D4ED8]" />
              <span>Public Emergency Services</span>
            </div>
            <h1 className="text-xl sm:text-3xl font-bold text-[#111827] tracking-tight">
              Report an Emergency Incident
            </h1>
            <p className="text-sm text-[#64748B] leading-relaxed">
              If you witness a natural disaster, accident, or hazard, submit a report with your location. Authority response units will review and dispatch assistance.
            </p>
          </div>

          <div className="shrink-0">
            <Link
              to="/citizen/report"
              className="inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-md bg-[#1D4ED8] hover:bg-blue-800 text-sm font-semibold text-white shadow-xs transition-colors"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Report an Incident</span>
            </Link>
          </div>
        </div>
      </div>

      {error && (
        <ErrorAlert
          title="Connection Notice"
          message={error}
          onRetry={() => {
            setIsRefreshing(true);
            loadData();
          }}
          isRetrying={isRefreshing}
        />
      )}

      {/* Grid: My Reports Summary + Emergency Helplines */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* My Reports Summary Card */}
        <div className="bg-white border border-[#E5E7EB] rounded-lg p-5 shadow-xs flex flex-col justify-between space-y-4">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-[#E5E7EB]">
              <span className="text-xs font-bold text-[#111827] uppercase flex items-center gap-1.5">
                <FileText className="w-4 h-4 text-[#1D4ED8]" />
                <span>My Submitted Reports</span>
              </span>
              <span className="text-xs px-2 py-0.5 rounded bg-blue-50 text-[#1D4ED8] font-semibold">
                {myReports.length}
              </span>
            </div>

            <div className="mt-4 space-y-2.5">
              {myReports.length === 0 ? (
                <div className="p-4 rounded-md border border-[#E5E7EB] bg-[#F5F7FA] text-center text-xs text-[#64748B]">
                  No reports submitted from this browser yet.
                </div>
              ) : (
                myReports.slice(0, 3).map((rep) => (
                  <div
                    key={rep.id}
                    className="p-3 rounded-md border border-[#E5E7EB] bg-[#F5F7FA] flex items-center justify-between gap-2"
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <DisasterIcon type={rep.disasterType} className="w-4 h-4 shrink-0" />
                      <div className="truncate">
                        <p className="text-xs font-semibold text-[#111827] truncate">
                          {rep.disasterType}
                        </p>
                        <p className="text-[11px] text-[#64748B] truncate">
                          {rep.location}
                        </p>
                      </div>
                    </div>
                    <StatusBadge status={rep.status} size="sm" />
                  </div>
                ))
              )}
            </div>
          </div>

          <Link
            to="/citizen/reports"
            className="w-full inline-flex items-center justify-center gap-1.5 py-2 px-3 rounded-md border border-[#E5E7EB] bg-white hover:bg-slate-50 text-xs font-semibold text-[#111827] transition-colors"
          >
            <span>View All My Reports ({myReports.length})</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        {/* 24/7 Emergency Helplines Directory */}
        <div className="lg:col-span-2 bg-white border border-[#E5E7EB] rounded-lg p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#E5E7EB]">
            <div>
              <span className="text-xs font-bold text-[#111827] uppercase flex items-center gap-1.5">
                <PhoneCall className="w-4 h-4 text-[#1D4ED8]" />
                <span>Emergency Helplines</span>
              </span>
              <p className="text-xs text-[#64748B] mt-0.5">Toll-free 24/7 national and regional emergency numbers</p>
            </div>
            <span className="text-xs text-[#059669] bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 font-semibold">
              Active 24/7
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
            {EMERGENCY_HELPLINES.map((hl) => (
              <div
                key={hl.number}
                className="p-3 rounded-md border border-[#E5E7EB] bg-[#F5F7FA] flex items-center justify-between gap-3"
              >
                <div>
                  <p className="text-xs font-semibold text-[#111827]">{hl.name}</p>
                  <p className="text-[11px] text-[#64748B]">{hl.desc}</p>
                </div>
                <a
                  href={`tel:${hl.number.split('/')[0].trim()}`}
                  className="px-2.5 py-1 rounded bg-white hover:bg-slate-50 text-[#1D4ED8] font-bold text-xs border border-[#E5E7EB] transition-colors shrink-0"
                >
                  {hl.number}
                </a>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Community Emergency Feed */}
      <div className="bg-white border border-[#E5E7EB] rounded-lg p-5 shadow-xs space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-[#E5E7EB]">
          <div>
            <h2 className="text-sm font-bold text-[#111827] flex items-center gap-2">
              <span>Recent Public Emergency Alerts</span>
            </h2>
            <p className="text-xs text-[#64748B]">
              Verified incidents in surrounding regions
            </p>
          </div>

          <button
            type="button"
            onClick={() => {
              setIsRefreshing(true);
              loadData();
            }}
            disabled={isLoading || isRefreshing}
            className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md border border-[#E5E7EB] bg-white text-xs font-medium text-[#111827] hover:bg-slate-50 transition-colors"
          >
            <RefreshCw className={`w-3 h-3 ${isRefreshing ? 'animate-spin' : ''}`} />
            <span>Refresh</span>
          </button>
        </div>

        {isLoading ? (
          <LoadingSpinner message="Loading emergency alerts..." />
        ) : recentCommunityIncidents.length === 0 ? (
          <div className="p-8 text-center text-xs text-[#64748B]">
            <CheckCircle2 className="w-6 h-6 text-[#059669] mx-auto mb-1" />
            <p className="font-semibold text-sm text-[#111827]">No active emergency alerts</p>
            <p className="text-xs text-[#64748B] mt-0.5">All monitored areas are currently safe.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {recentCommunityIncidents.map((incident) => (
              <div
                key={incident.id}
                className="p-4 rounded-md border border-[#E5E7EB] bg-[#F5F7FA] flex flex-col justify-between space-y-3"
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-[#111827]">
                      #{incident.id}
                    </span>
                    <StatusBadge status={incident.status} size="sm" />
                  </div>

                  <div className="flex items-center gap-2">
                    <DisasterIcon type={incident.disasterType} showContainer size="sm" />
                    <div>
                      <h4 className="font-bold text-[#111827] text-xs">
                        {incident.disasterType}
                      </h4>
                      <span className="text-[10px] text-[#64748B]">Incident Record</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-1 text-xs text-[#64748B]">
                    <MapPin className="w-3.5 h-3.5 text-[#64748B] shrink-0" />
                    <span className="truncate">{incident.location}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default CitizenDashboard;
