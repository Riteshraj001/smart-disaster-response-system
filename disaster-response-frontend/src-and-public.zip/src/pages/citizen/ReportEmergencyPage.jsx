import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import {
  MapPin,
  Compass,
  AlertTriangle,
  Users,
  Camera,
  CheckCircle2,
  Loader2,
  ArrowLeft,
  Navigation,
} from 'lucide-react';
import { DISASTER_TYPES } from '../../constants/incidentConstants';
import incidentService from '../../services/incidentService';
import { useNotification } from '../../context/NotificationContext';
import DisasterIcon from '../../components/common/DisasterIcon';
import ErrorAlert from '../../components/common/ErrorAlert';

const ReportEmergencyPage = () => {
  const navigate = useNavigate();
  const { showToast } = useNotification();

  const [formData, setFormData] = useState({
    disasterType: '',
    location: '',
    description: '',
    peopleAffected: 'None',
    evidenceFile: null,
  });

  const [geoData, setGeoData] = useState({
    latitude: null,
    longitude: null,
    accuracy: null,
    isLocating: false,
    geoError: null,
  });

  const [errors, setErrors] = useState({});
  const [touched, setTouched] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [serverError, setServerError] = useState(null);

  // Geolocation handler
  const handleUseCurrentLocation = () => {
    if (!navigator.geolocation) {
      setGeoData((prev) => ({
        ...prev,
        geoError: 'Browser geolocation is not supported on this device.',
      }));
      return;
    }

    setGeoData((prev) => ({ ...prev, isLocating: true, geoError: null }));

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const { latitude, longitude, accuracy } = position.coords;
        const formattedCoords = `${latitude.toFixed(6)}, ${longitude.toFixed(6)}`;

        setGeoData({
          latitude: latitude.toFixed(6),
          longitude: longitude.toFixed(6),
          accuracy: Math.round(accuracy),
          isLocating: false,
          geoError: null,
        });

        setFormData((prev) => ({
          ...prev,
          location: prev.location ? `${prev.location} (${formattedCoords})` : formattedCoords,
        }));

        setErrors((prev) => ({ ...prev, location: '' }));
      },
      (err) => {
        console.warn('Geolocation failed:', err);
        let msg = 'Unable to retrieve your location. Please type your location manually.';
        if (err.code === 1) msg = 'Location permission denied. Please allow access in browser.';
        else if (err.code === 2) msg = 'Location unavailable. Please check GPS signal.';
        else if (err.code === 3) msg = 'Location request timed out.';

        setGeoData((prev) => ({
          ...prev,
          isLocating: false,
          geoError: msg,
        }));
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
    );
  };

  const validate = (data) => {
    const errs = {};
    if (!data.disasterType?.trim()) {
      errs.disasterType = 'Please select the disaster type.';
    }
    if (!data.location?.trim()) {
      errs.location = 'Incident location is required.';
    } else if (data.location.trim().length < 2) {
      errs.location = 'Location must be at least 2 characters.';
    }
    return errs;
  };

  const handleChange = (field, value) => {
    setFormData((prev) => {
      const updated = { ...prev, [field]: value };
      if (touched[field]) {
        const valErrors = validate(updated);
        setErrors((prevErr) => ({ ...prevErr, [field]: valErrors[field] || '' }));
      }
      return updated;
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setTouched({ disasterType: true, location: true });

    const valErrors = validate(formData);
    setErrors(valErrors);
    if (Object.keys(valErrors).length > 0) return;

    setIsSubmitting(true);
    setServerError(null);

    try {
      const payload = {
        disasterType: formData.disasterType.trim(),
        location: formData.location.trim(),
        status: 'Pending',
        description: formData.description?.trim(),
        peopleAffected: formData.peopleAffected,
        latitude: geoData.latitude,
        longitude: geoData.longitude,
        accuracy: geoData.accuracy,
      };

      await incidentService.createIncident(payload);
      showToast('Incident report submitted successfully.', 'success');
      navigate('/citizen/reports');
    } catch (err) {
      console.error('Failed to submit emergency report:', err);
      setServerError(
        err.message || 'Failed to connect to the backend server. Please try again.'
      );
      showToast(err.message || 'Failed to submit report.', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6 font-sans">
      <div>
        <Link
          to="/citizen"
          className="inline-flex items-center gap-1.5 text-xs font-medium text-[#64748B] hover:text-[#111827] transition-colors mb-3"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Dashboard</span>
        </Link>

        <h1 className="text-xl sm:text-2xl font-bold text-[#111827]">
          Report an Emergency
        </h1>
        <p className="text-xs sm:text-sm text-[#64748B] mt-0.5">
          Provide the details below so the nearest authority can review your report.
        </p>
      </div>

      {serverError && (
        <ErrorAlert
          title="Submission Error"
          message={serverError}
          showCorsHint={false}
        />
      )}

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="bg-white border border-[#E5E7EB] rounded-lg p-6 shadow-xs space-y-6">
          {/* Disaster Type Selection */}
          <div className="space-y-2.5">
            <label className="block text-xs font-bold uppercase text-[#111827]">
                Disaster Type <span className="text-[#DC2626]">*</span>
            </label>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {DISASTER_TYPES.map((type) => {
                const isSelected = formData.disasterType === type;
                return (
                  <button
                    key={type}
                    type="button"
                    onClick={() => handleChange('disasterType', type)}
                    className={`p-2.5 rounded-md border text-center flex flex-col items-center justify-center gap-1.5 transition-colors ${
                      isSelected
                        ? 'border-[#1D4ED8] bg-blue-50 text-[#1D4ED8] font-semibold'
                        : 'border-[#E5E7EB] bg-white text-[#111827] hover:bg-slate-50'
                    }`}
                  >
                    <DisasterIcon type={type} showContainer size="sm" />
                    <span className="text-xs">{type}</span>
                  </button>
                );
              })}
            </div>

            {errors.disasterType && (
              <p className="text-xs text-[#DC2626] font-medium mt-1">
                {errors.disasterType}
              </p>
            )}
          </div>

          {/* Location Input */}
          <div className="space-y-2 pt-4 border-t border-[#E5E7EB]">
            <div className="flex items-center justify-between">
              <label htmlFor="location" className="block text-xs font-bold uppercase text-[#111827]">
                Location <span className="text-[#DC2626]">*</span>
              </label>

              <button
                type="button"
                onClick={handleUseCurrentLocation}
                disabled={geoData.isLocating}
                className="inline-flex items-center gap-1 text-xs text-[#1D4ED8] hover:text-blue-800 font-medium disabled:opacity-50"
              >
                {geoData.isLocating ? (
                  <>
                    <Loader2 className="w-3 h-3 animate-spin" />
                    <span>Getting GPS...</span>
                  </>
                ) : (
                  <>
                    <Navigation className="w-3 h-3" />
                    <span>Use My Location</span>
                  </>
                )}
              </button>
            </div>

            {geoData.latitude && (
              <div className="p-2 rounded bg-emerald-50 border border-emerald-200 text-xs text-[#059669] flex items-center justify-between">
                <span>GPS: {geoData.latitude}, {geoData.longitude}</span>
                {geoData.accuracy && <span>&plusmn;{geoData.accuracy}m</span>}
              </div>
            )}

            {geoData.geoError && (
              <p className="text-xs text-[#D97706]">{geoData.geoError}</p>
            )}

            <input
              type="text"
              id="location"
              value={formData.location}
              onChange={(e) => handleChange('location', e.target.value)}
              placeholder="e.g. College Block A, Main Gate, Road 14"
              className={`w-full rounded-md border bg-white px-3 py-2 text-sm text-[#111827] placeholder-[#64748B] focus:outline-none focus:ring-1 focus:ring-[#1D4ED8] ${
                errors.location ? 'border-[#DC2626]' : 'border-[#E5E7EB]'
              }`}
            />

            {errors.location && (
              <p className="text-xs text-[#DC2626] font-medium mt-1">
                {errors.location}
              </p>
            )}
          </div>

          {/* Description */}
          <div className="space-y-1.5 pt-4 border-t border-[#E5E7EB]">
            <label htmlFor="description" className="block text-xs font-bold uppercase text-[#111827]">
              Description (Optional)
            </label>
            <textarea
              id="description"
              rows={3}
              value={formData.description}
              onChange={(e) => handleChange('description', e.target.value)}
              placeholder="Provide additional details regarding the incident..."
              className="w-full rounded-md border border-[#E5E7EB] bg-white px-3 py-2 text-sm text-[#111827] placeholder-[#64748B] focus:outline-none focus:ring-1 focus:ring-[#1D4ED8]"
            />
          </div>

          {/* People Affected */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4 border-t border-[#E5E7EB]">
            <div className="space-y-1.5">
              <label className="block text-xs font-bold uppercase text-[#111827]">
                Estimated People Affected
              </label>
              <select
                value={formData.peopleAffected}
                onChange={(e) => handleChange('peopleAffected', e.target.value)}
                className="w-full rounded-md border border-[#E5E7EB] bg-white px-3 py-2 text-xs text-[#111827] focus:outline-none focus:ring-1 focus:ring-[#1D4ED8]"
              >
                <option value="None">None / Unknown</option>
                <option value="1-5">1 – 5 people</option>
                <option value="5-20">5 – 20 people</option>
                <option value="20+">20+ people</option>
              </select>
            </div>

            <div className="space-y-1.5">
              <label className="block text-xs font-bold uppercase text-[#111827]">
                Photo Attachment (Optional)
              </label>
              <div className="relative border border-dashed border-[#E5E7EB] rounded-md p-2 text-center bg-[#F5F7FA] hover:bg-slate-100 transition-colors cursor-pointer">
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) =>
                    setFormData((prev) => ({
                      ...prev,
                      evidenceFile: e.target.files?.[0]?.name || null,
                    }))
                  }
                  className="absolute inset-0 opacity-0 cursor-pointer"
                />
                <span className="text-xs text-[#64748B]">
                  {formData.evidenceFile ? `Attached: ${formData.evidenceFile}` : 'Choose an image file'}
                </span>
              </div>
            </div>
          </div>
        </div>

        <div className="flex items-center justify-end gap-3">
          <button
            type="button"
            onClick={() => navigate('/citizen')}
            disabled={isSubmitting}
            className="px-4 py-2 rounded-md border border-[#E5E7EB] bg-white hover:bg-slate-50 text-xs font-semibold text-[#111827] transition-colors"
          >
            Cancel
          </button>

          <button
            type="submit"
            disabled={isSubmitting}
            className="px-6 py-2 rounded-md bg-[#1D4ED8] hover:bg-blue-800 text-xs font-semibold text-white transition-colors shadow-xs disabled:opacity-50 inline-flex items-center gap-1.5"
          >
            {isSubmitting ? (
              <>
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
                <span>Submitting...</span>
              </>
            ) : (
            <span>Submit Incident</span>
            )}
          </button>
        </div>
      </form>
    </div>
  );
};

export default ReportEmergencyPage;
