import React, { useState } from 'react';
import {
  Server,
  Layers,
  Code2,
  Shield,
  Cpu,
  Database,
  Radio,
  BookOpen,
  Copy,
  Check,
} from 'lucide-react';
import { API_BASE_URL } from '../constants/incidentConstants';

const AboutSystem = () => {
  const [copiedCode, setCopiedCode] = useState(null);

  const copyToClipboard = (code, key) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(key);
    setTimeout(() => setCopiedCode(null), 2000);
  };

  const corsAnnotationCode = `// Option A: Add @CrossOrigin on your IncidentController in Spring Boot
package com.example.disasterresponse.controller;

import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/incidents")
@CrossOrigin(origins = "http://localhost:5173", allowedHeaders = "*", methods = {
    RequestMethod.GET,
    RequestMethod.POST,
    RequestMethod.PUT,
    RequestMethod.DELETE
})
public class IncidentController {
    // Controller endpoints...
}`;

  const corsGlobalConfigCode = `// Option B: Global CORS Configuration in Spring Boot
package com.example.disasterresponse.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class CorsConfig implements WebMvcConfigurer {

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**")
                .allowedOrigins("http://localhost:5173")
                .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS")
                .allowedHeaders("*")
                .allowCredentials(true);
    }
}`;

  return (
    <div className="max-w-5xl mx-auto space-y-8 pb-12 font-sans">
      {/* Header */}
      <div className="pb-2 border-b border-[#E5E7EB]">
        <h1 className="text-xl sm:text-2xl font-bold text-[#111827]">
          System Documentation &amp; Architecture
        </h1>
        <p className="text-xs sm:text-sm text-[#64748B] mt-0.5">
          Engineering architecture, REST API specifications, and Spring Boot backend integration.
        </p>
      </div>

      {/* Section 1: Full-Stack Architecture Overview */}
      <section className="bg-white border border-[#E5E7EB] rounded-lg p-6 shadow-xs space-y-5">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded bg-blue-50 text-[#1D4ED8]">
            <Layers className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-[#111827]">Full-Stack Architecture</h2>
            <p className="text-xs text-[#64748B]">Layered architecture separating UI, services, controllers, and persistence</p>
          </div>
        </div>

        {/* Visual Architecture Flow Diagram */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="p-4 rounded-md border border-[#E5E7EB] bg-[#F5F7FA] space-y-2">
            <span className="text-[11px] font-semibold text-[#1D4ED8] block">Layer 1: Frontend</span>
            <h3 className="font-bold text-[#111827] text-sm">React 19 + Tailwind CSS</h3>
            <p className="text-xs text-[#64748B] leading-relaxed">
              Vite build system, reusable components, Lucide icons, Recharts dashboards, Leaflet maps.
            </p>
          </div>

          <div className="p-4 rounded-md border border-[#E5E7EB] bg-[#F5F7FA] space-y-2">
            <span className="text-[11px] font-semibold text-[#1D4ED8] block">Layer 2: HTTP Client</span>
            <h3 className="font-bold text-[#111827] text-sm">Axios Service Layer</h3>
            <p className="text-xs text-[#64748B] leading-relaxed">
              Centralized <code className="text-[#111827] font-semibold">incidentService.js</code> with timeout handling and error interceptors.
            </p>
          </div>

          <div className="p-4 rounded-md border border-[#E5E7EB] bg-[#F5F7FA] space-y-2">
            <span className="text-[11px] font-semibold text-[#1D4ED8] block">Layer 3: Backend API</span>
            <h3 className="font-bold text-[#111827] text-sm">Spring Boot 3 REST API</h3>
            <p className="text-xs text-[#64748B] leading-relaxed">
              REST Controllers, DTO validation, Spring Data JPA Repository, and CORS filter.
            </p>
          </div>

          <div className="p-4 rounded-md border border-[#E5E7EB] bg-[#F5F7FA] space-y-2">
            <span className="text-[11px] font-semibold text-[#1D4ED8] block">Layer 4: Data Store</span>
            <h3 className="font-bold text-[#111827] text-sm">Relational Database</h3>
            <p className="text-xs text-[#64748B] leading-relaxed">
              MySQL or H2 database storing incident entities with primary key indexing.
            </p>
          </div>
        </div>
      </section>

      {/* Section 2: REST API Mapping Table */}
      <section className="bg-white border border-[#E5E7EB] rounded-lg p-6 shadow-xs space-y-5">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded bg-blue-50 text-[#1D4ED8]">
            <Code2 className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-[#111827]">REST API Specification</h2>
            <p className="text-xs text-[#64748B]">Implemented endpoints on Spring Boot backend at {API_BASE_URL}</p>
          </div>
        </div>

        <div className="overflow-x-auto rounded-lg border border-[#E5E7EB]">
          <table className="w-full text-left text-xs text-[#111827]">
            <thead className="border-b border-[#E5E7EB] bg-[#F5F7FA] text-[11px] font-semibold uppercase text-[#64748B]">
              <tr>
                <th className="py-2.5 px-4">Method</th>
                <th className="py-2.5 px-4">Endpoint</th>
                <th className="py-2.5 px-4">Request Body</th>
                <th className="py-2.5 px-4">Response</th>
                <th className="py-2.5 px-4">Description</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#E5E7EB]">
              <tr className="hover:bg-slate-50">
                <td className="py-2.5 px-4 font-bold text-[#1D4ED8]">GET</td>
                <td className="py-2.5 px-4 font-mono">/incidents</td>
                <td className="py-2.5 px-4 text-[#64748B]">None</td>
                <td className="py-2.5 px-4 text-[#059669] font-medium">200 OK (List)</td>
                <td className="py-2.5 px-4 text-[#64748B]">Fetches all incident records</td>
              </tr>
              <tr className="hover:bg-slate-50">
                <td className="py-2.5 px-4 font-bold text-[#1D4ED8]">GET</td>
                <td className="py-2.5 px-4 font-mono">/incidents/&#123;id&#125;</td>
                <td className="py-2.5 px-4 text-[#64748B]">None</td>
                <td className="py-2.5 px-4 text-[#059669] font-medium">200 OK (Object)</td>
                <td className="py-2.5 px-4 text-[#64748B]">Fetches single incident details by ID</td>
              </tr>
              <tr className="hover:bg-slate-50">
                <td className="py-2.5 px-4 font-bold text-[#059669]">POST</td>
                <td className="py-2.5 px-4 font-mono">/incidents</td>
                <td className="py-2.5 px-4 text-[#111827] font-mono">&#123; disasterType, location, status &#125;</td>
                <td className="py-2.5 px-4 text-[#059669] font-medium">201 Created</td>
                <td className="py-2.5 px-4 text-[#64748B]">Creates a new emergency incident</td>
              </tr>
              <tr className="hover:bg-slate-50">
                <td className="py-2.5 px-4 font-bold text-[#D97706]">PUT</td>
                <td className="py-2.5 px-4 font-mono">/incidents/&#123;id&#125;</td>
                <td className="py-2.5 px-4 text-[#111827] font-mono">&#123; disasterType, location, status &#125;</td>
                <td className="py-2.5 px-4 text-[#059669] font-medium">200 OK</td>
                <td className="py-2.5 px-4 text-[#64748B]">Updates incident details by ID</td>
              </tr>
              <tr className="hover:bg-slate-50">
                <td className="py-2.5 px-4 font-bold text-[#DC2626]">DELETE</td>
                <td className="py-2.5 px-4 font-mono">/incidents/&#123;id&#125;</td>
                <td className="py-2.5 px-4 text-[#64748B]">None</td>
                <td className="py-2.5 px-4 text-[#059669] font-medium">204 No Content</td>
                <td className="py-2.5 px-4 text-[#64748B]">Deletes incident from database</td>
              </tr>
            </tbody>
          </table>
        </div>
      </section>

      {/* Section 3: Spring Boot CORS Guide */}
      <section className="bg-white border border-[#E5E7EB] rounded-lg p-6 shadow-xs space-y-5">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded bg-blue-50 text-[#1D4ED8]">
            <Shield className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-[#111827]">Spring Boot CORS Configuration</h2>
            <p className="text-xs text-[#64748B]">Allow cross-origin requests from http://localhost:5173 to Spring Boot on port 8080</p>
          </div>
        </div>

        {/* Code Snippet Option A */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs text-[#64748B]">
            <span className="font-semibold text-[#111827]">Option 1: Controller-level @CrossOrigin annotation</span>
            <button
              onClick={() => copyToClipboard(corsAnnotationCode, 'ann')}
              className="inline-flex items-center gap-1 px-2.5 py-1 rounded border border-[#E5E7EB] bg-white hover:bg-slate-50 text-xs font-semibold text-[#111827] transition-colors"
            >
              {copiedCode === 'ann' ? (
                <>
                  <Check className="w-3.5 h-3.5 text-[#059669]" />
                  <span className="text-[#059669]">Copied</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy Code</span>
                </>
              )}
            </button>
          </div>
          <pre className="rounded-md border border-[#E5E7EB] bg-[#F5F7FA] p-4 text-xs font-mono text-[#111827] overflow-x-auto">
            {corsAnnotationCode}
          </pre>
        </div>

        {/* Code Snippet Option B */}
        <div className="space-y-2 pt-3 border-t border-[#E5E7EB]">
          <div className="flex items-center justify-between text-xs text-[#64748B]">
            <span className="font-semibold text-[#111827]">Option 2: Global WebMvcConfigurer configuration class</span>
            <button
              onClick={() => copyToClipboard(corsGlobalConfigCode, 'global')}
              className="inline-flex items-center gap-1 px-2.5 py-1 rounded border border-[#E5E7EB] bg-white hover:bg-slate-50 text-xs font-semibold text-[#111827] transition-colors"
            >
              {copiedCode === 'global' ? (
                <>
                  <Check className="w-3.5 h-3.5 text-[#059669]" />
                  <span className="text-[#059669]">Copied</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy Code</span>
                </>
              )}
            </button>
          </div>
          <pre className="rounded-md border border-[#E5E7EB] bg-[#F5F7FA] p-4 text-xs font-mono text-[#111827] overflow-x-auto">
            {corsGlobalConfigCode}
          </pre>
        </div>
      </section>
    </div>
  );
};

export default AboutSystem;

