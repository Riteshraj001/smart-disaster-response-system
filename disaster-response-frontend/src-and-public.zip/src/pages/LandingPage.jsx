import React from 'react';
import { Link } from 'react-router-dom';
import { ShieldAlert, UserRound, ShieldCheck, Settings, ArrowUpRight } from 'lucide-react';
import networkBackground from '../assets/disaster-network-background.png';

const loginOptions = [
  {
    title: 'Citizen Portal',
    accessLabel: 'Public Access',
    button: 'Citizen Login',
    to: '/login/citizen',
    icon: UserRound,
  },
  {
    title: 'Authority Portal',
    accessLabel: 'Authorized Access',
    button: 'Authority Login',
    to: '/login/authority',
    icon: ShieldCheck,
  },
  {
    title: 'Administrator',
    accessLabel: 'System Administration',
    button: 'Admin Login',
    to: '/login/admin',
    icon: Settings,
  },
];

const LandingPage = () => (
    <div
      className="relative min-h-screen overflow-hidden bg-[#07152f] font-sans text-white"
      style={{ backgroundImage: `url(${networkBackground})`, backgroundPosition: 'center', backgroundRepeat: 'no-repeat', backgroundSize: 'cover' }}
    >
      <div className="absolute inset-0 bg-[#07152f]/88" aria-hidden="true" />

      <div className="relative z-10 flex min-h-screen flex-col">
        <main className="flex flex-1 items-center">
          <div className="mx-auto w-full max-w-6xl px-4 py-10 sm:px-6 lg:px-8">
            <section className="mx-auto max-w-2xl text-center">
              <span className="mx-auto flex h-11 w-11 items-center justify-center rounded-md border border-white/20 bg-white/10 text-white">
                <ShieldAlert className="h-5 w-5" aria-hidden="true" />
              </span>
              <p className="mt-3 text-base font-semibold text-white">Smart Disaster Management</p>
              <p className="mt-1 text-sm text-slate-300">Emergency Response System</p>
              <h1 className="mt-5 text-2xl font-bold tracking-tight text-white sm:text-3xl">
                Smart Disaster Management &amp; Emergency Response System
              </h1>
              <p className="mx-auto mt-3 max-w-xl text-base leading-7 text-slate-200">
                An integrated platform for reporting, detecting and coordinating disaster response.
              </p>
            </section>

            <section aria-label="Portal access" className="mx-auto mt-8 grid max-w-4xl grid-cols-1 gap-4 md:grid-cols-3">
              {loginOptions.map(({ title, accessLabel, button, to, icon: Icon }) => (
                <article key={title} className="flex h-48 flex-col rounded-lg border border-white/15 bg-[#0F172A]/90 p-5 shadow-[0_1px_3px_rgba(0,0,0,0.22)]">
                  <span className="flex h-8 w-8 items-center justify-center rounded-md border border-white/15 bg-white/10 text-slate-100">
                    <Icon className="h-4 w-4" aria-hidden="true" />
                  </span>
                  <h2 className="mt-4 text-lg font-semibold text-white">{title}</h2>
                  <p className="mt-1 text-sm text-[#94A3B8]">{accessLabel}</p>
                  <Link
                    to={to}
                    aria-label={button}
                    title={button}
                    className="mt-auto inline-flex h-12 w-12 items-center justify-center self-end rounded-full bg-[#2563EB] text-white transition duration-150 hover:scale-[1.03] hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-300 focus:ring-offset-2 focus:ring-offset-[#0F172A]"
                  >
                    <ArrowUpRight className="h-5 w-5" aria-hidden="true" />
                  </Link>
                </article>
              ))}
            </section>
          </div>
        </main>

        <footer className="shrink-0 border-t border-white/15 bg-[#07152f]/70 px-4 py-4 text-center text-xs text-slate-300">
          <p>Smart Disaster Management &amp; Emergency Response System</p>
          <p className="mt-1 text-slate-400">Emergency reporting &bull; IoT detection &bull; Coordinated response</p>
        </footer>
      </div>
    </div>
);

export default LandingPage;
