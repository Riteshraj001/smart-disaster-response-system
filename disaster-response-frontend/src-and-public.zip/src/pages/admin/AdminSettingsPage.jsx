import React, { useState } from 'react';
import { Settings, Save, Server, Globe } from 'lucide-react';
import { useNotification } from '../../context/NotificationContext';

const AdminSettingsPage = () => {
  const { showToast } = useNotification();
  const [apiUrl, setApiUrl] = useState('http://localhost:8080');
  const [mqttBroker, setMqttBroker] = useState('tcp://localhost:1883');
  const [autoTriage, setAutoTriage] = useState(true);
  const [geolocationEnforce, setGeolocationEnforce] = useState(true);

  const handleSave = (e) => {
    e.preventDefault();
    showToast('System configuration parameters saved.', 'success');
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6 font-sans">
      <div className="pb-2 border-b border-[#E5E7EB]">
        <h1 className="text-xl sm:text-2xl font-bold text-[#111827]">
          Platform Settings
        </h1>
        <p className="text-xs sm:text-sm text-[#64748B] mt-0.5">
          Configure API endpoints, threshold rules, and system behavior.
        </p>
      </div>

      <form onSubmit={handleSave} className="space-y-6">
        <div className="bg-white border border-[#E5E7EB] rounded-lg p-6 shadow-xs space-y-6">
          <div className="space-y-1.5">
            <label className="block text-xs font-bold uppercase text-[#111827]">
              Spring Boot Backend API URL
            </label>
            <input
              type="text"
              value={apiUrl}
              onChange={(e) => setApiUrl(e.target.value)}
              className="w-full rounded-md border border-[#E5E7EB] bg-white px-3 py-2 text-sm text-[#111827] focus:outline-none focus:ring-1 focus:ring-[#1D4ED8]"
            />
            <p className="text-xs text-[#64748B]">
              Active endpoint for incident REST operations (Default: <code>http://localhost:8080</code>).
            </p>
          </div>

          <div className="space-y-1.5 pt-4 border-t border-[#E5E7EB]">
            <label className="block text-xs font-bold uppercase text-[#111827]">
              MQTT Broker Host (IoT Sensor Bridge)
            </label>
            <input
              type="text"
              value={mqttBroker}
              onChange={(e) => setMqttBroker(e.target.value)}
              className="w-full rounded-md border border-[#E5E7EB] bg-white px-3 py-2 text-sm text-[#111827] focus:outline-none focus:ring-1 focus:ring-[#1D4ED8]"
            />
            <p className="text-xs text-[#64748B]">
              Connection string for IoT sensor microcontroller telemetry feed.
            </p>
          </div>

          <div className="space-y-4 pt-4 border-t border-[#E5E7EB]">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-semibold text-[#111827]">Automatic Sensor Incident Creation</p>
                <p className="text-xs text-[#64748B]">
                  Automatically create an incident record when sensor thresholds are breached.
                </p>
              </div>
              <input
                type="checkbox"
                checked={autoTriage}
                onChange={(e) => setAutoTriage(e.target.checked)}
                className="h-4 w-4 rounded border-[#E5E7EB] text-[#1D4ED8] focus:ring-[#1D4ED8]"
              />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-semibold text-[#111827]">Require GPS Capture for Citizen Reports</p>
                <p className="text-xs text-[#64748B]">
                  Prompt users for browser GPS geolocation when submitting a new emergency report.
                </p>
              </div>
              <input
                type="checkbox"
                checked={geolocationEnforce}
                onChange={(e) => setGeolocationEnforce(e.target.checked)}
                className="h-4 w-4 rounded border-[#E5E7EB] text-[#1D4ED8] focus:ring-[#1D4ED8]"
              />
            </div>
          </div>
        </div>

        <div className="flex justify-end">
          <button
            type="submit"
            className="inline-flex items-center gap-1.5 px-5 py-2 rounded-md bg-[#1D4ED8] hover:bg-blue-800 text-xs font-semibold text-white shadow-xs transition-colors"
          >
            <Save className="w-3.5 h-3.5" />
            <span>Save Settings</span>
          </button>
        </div>
      </form>
    </div>
  );
};

export default AdminSettingsPage;

