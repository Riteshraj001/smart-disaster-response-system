import React from 'react';
import { Link } from 'react-router-dom';
import { ShieldCheck, ArrowRight } from 'lucide-react';
import LiveIncidentsPage from '../authority/LiveIncidentsPage';

const AdminIncidentsPage = () => {
  return (
    <div className="space-y-6 font-sans">
      {/* Incident List */}
      <LiveIncidentsPage />
    </div>
  );
};

export default AdminIncidentsPage;

