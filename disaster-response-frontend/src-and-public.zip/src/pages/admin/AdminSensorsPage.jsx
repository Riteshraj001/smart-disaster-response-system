import React, { useState } from 'react';
import { Cpu, Plus, AlertTriangle, CheckCircle2 } from 'lucide-react';

const SENSOR_INVENTORY = [
  {
    id: 'SM-001',
    type: 'Smoke Sensor (MQ-2)',
    location: 'College Block A - Level 2',
    reading: '650 ppm',
    threshold: '500 ppm',
    status: 'ALERT',
    lastUpdated: '20 Aug 2026, 11:05 AM',
  },
  {
    id: 'WATER-002',
    type: 'Water Level Sensor (Ultrasonic)',
    location: 'Campus Gate & Drainage Channel',
    reading: '40 cm',
    threshold: '100 cm',
    status: 'NORMAL',
    lastUpdated: '20 Aug 2026, 11:04 AM',
  },
  {
    id: 'FLM-003',
    type: 'Flame Sensor (IR Optical)',
    location: 'Chemistry Lab & Chemical Store',
    reading: '0.02 lux',
    threshold: '0.80 lux',
    status: 'NORMAL',
    lastUpdated: '20 Aug 2026, 11:05 AM',
  },
  {
    id: 'TEMP-004',
    type: 'Temperature Sensor (DHT22)',
    location: 'Server Room & Power Substation',
    reading: '28°C',
    threshold: '45°C',
    status: 'NORMAL',
    lastUpdated: '20 Aug 2026, 11:03 AM',
  },
  {
    id: 'GAS-005',
    type: 'Gas Leak Sensor (MQ-5)',
    location: 'Cafeteria Kitchen Gas Line',
    reading: '180 ppm',
    threshold: '400 ppm',
    status: 'NORMAL',
    lastUpdated: '20 Aug 2026, 11:02 AM',
  },
];

const AdminSensorsPage = () => {
  const [sensors] = useState(SENSOR_INVENTORY);

  return (
    <div className="space-y-6 font-sans">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-[#E5E7EB]">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-[#111827]">
            IoT Sensors &amp; Node Inventory
          </h1>
          <p className="text-xs sm:text-sm text-[#64748B] mt-0.5">
            Configure threshold limits, inspect live readings, and manage hardware node registration.
          </p>
        </div>

        <button
          type="button"
          onClick={() => alert('Sensor Node Registration dialog will be configured.')}
          className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-md bg-[#1D4ED8] hover:bg-blue-800 text-xs font-semibold text-white shadow-xs transition-colors"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Add Sensor Node</span>
        </button>
      </div>

      <div className="overflow-hidden rounded-lg border border-[#E5E7EB] bg-white shadow-xs">
        <table className="w-full text-left text-xs text-[#111827]">
          <thead className="border-b border-[#E5E7EB] bg-[#F5F7FA] text-[11px] font-semibold uppercase text-[#64748B]">
            <tr>
              <th className="py-2.5 px-4">Sensor ID</th>
              <th className="py-2.5 px-4">Sensor Type</th>
              <th className="py-2.5 px-4">Location</th>
              <th className="py-2.5 px-4">Reading</th>
              <th className="py-2.5 px-4">Threshold</th>
              <th className="py-2.5 px-4">Status</th>
              <th className="py-2.5 px-4">Last Updated</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#E5E7EB]">
            {sensors.map((s) => {
              const isAlert = s.status === 'ALERT';
              return (
                <tr key={s.id} className="hover:bg-slate-50 transition-colors">
                  <td className="py-3 px-4 font-semibold text-[#111827]">{s.id}</td>
                  <td className="py-3 px-4 font-medium text-[#111827]">{s.type}</td>
                  <td className="py-3 px-4 text-[#64748B]">{s.location}</td>
                  <td className={`py-3 px-4 font-semibold ${isAlert ? 'text-[#DC2626]' : 'text-[#111827]'}`}>
                    {s.reading}
                  </td>
                  <td className="py-3 px-4 text-[#64748B]">{s.threshold}</td>
                  <td className="py-3 px-4">
                    {isAlert ? (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-bold bg-red-50 text-[#DC2626] border border-red-200">
                        <AlertTriangle className="w-3 h-3" />
                        ALERT
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-bold bg-emerald-50 text-[#059669] border border-emerald-200">
                        <CheckCircle2 className="w-3 h-3" />
                        NORMAL
                      </span>
                    )}
                  </td>
                  <td className="py-3 px-4 text-[#64748B]">{s.lastUpdated}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default AdminSensorsPage;

