import React, { useState, useEffect } from 'react';
import {
  Building,
  Cpu,
  Activity,
  Server,
  ShieldCheck,
  Radio,
} from 'lucide-react';
import incidentService from '../../services/incidentService';
import StatCard from '../../components/common/StatCard';

const AdminDashboard = () => {
  const [incidentCount, setIncidentCount] = useState(0);
  const [backendOnline, setBackendOnline] = useState(true);

  useEffect(() => {
    const check = async () => {
      const isOnline = await incidentService.checkBackendHealth();
      setBackendOnline(isOnline);
      if (isOnline) {
        const data = await incidentService.getIncidents();
        if (Array.isArray(data)) setIncidentCount(data.length);
      }
    };
    check();
  }, []);

  return (
    <div className="space-y-6 font-sans">
      {/* Header */}
      <div className="pb-2 border-b border-[#E5E7EB]">
        <h1 className="text-xl sm:text-2xl font-bold text-[#111827]">
          System Administration
        </h1>
        <p className="text-xs sm:text-sm text-[#64748B] mt-0.5">
          Overview of system health, security roles, connected nodes, and database statistics.
        </p>
      </div>

      {/* Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Total Incidents"
          value={incidentCount}
          icon={Radio}
          variant="default"
          subtitle="Spring Boot database entities"
        />
        <StatCard
          title="IoT Sensors Configured"
          value="5 Sensors"
          icon={Cpu}
          variant="resolved"
          subtitle="Smoke, Water, Flame, Temp, Gas"
        />
        <StatCard
          title="Authority Stations"
          value="4 Units"
          icon={Building}
          variant="default"
          subtitle="Fire, NDRF, EMS, Police"
        />
        <StatCard
          title="Backend API Status"
          value={backendOnline ? 'Online' : 'Offline'}
          icon={Activity}
          variant={backendOnline ? 'resolved' : 'active'}
          subtitle="Spring Boot (Port 8080)"
        />
      </div>

      {/* RBAC & Architecture Readiness Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Module 1: Role-Based Access Control */}
        <div className="bg-white border border-[#E5E7EB] rounded-lg p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#E5E7EB]">
            <div className="flex items-center gap-2">
              <div className="p-1.5 rounded bg-blue-50 text-[#1D4ED8]">
                <ShieldCheck className="w-4 h-4" />
              </div>
              <h3 className="text-sm font-bold text-[#111827]">Role-Based Access Control</h3>
            </div>
            <span className="text-xs font-semibold text-[#1D4ED8] bg-blue-50 px-2 py-0.5 rounded">
              3 Roles
            </span>
          </div>

          <p className="text-xs text-[#64748B] leading-relaxed">
            The platform provides structured separation of concerns for three user roles:
          </p>

          <div className="space-y-2 text-xs">
            <div className="p-3 rounded-md border border-[#E5E7EB] bg-[#F5F7FA] flex items-center justify-between">
              <span className="text-[#111827] font-semibold">ROLE_CITIZEN</span>
              <span className="text-[#64748B]">Report emergencies, view personal reports &amp; safety guides</span>
            </div>
            <div className="p-3 rounded-md border border-[#E5E7EB] bg-[#F5F7FA] flex items-center justify-between">
              <span className="text-[#111827] font-semibold">ROLE_AUTHORITY</span>
              <span className="text-[#64748B]">Verify, dispatch teams, update status, view maps &amp; analytics</span>
            </div>
            <div className="p-3 rounded-md border border-[#E5E7EB] bg-[#F5F7FA] flex items-center justify-between">
              <span className="text-[#111827] font-semibold">ROLE_ADMIN</span>
              <span className="text-[#64748B]">Manage system configurations, user accounts, and health checks</span>
            </div>
          </div>
        </div>

        {/* Module 2: System Telemetry */}
        <div className="bg-white border border-[#E5E7EB] rounded-lg p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#E5E7EB]">
            <div className="flex items-center gap-2">
              <div className="p-1.5 rounded bg-emerald-50 text-[#059669]">
                <Server className="w-4 h-4" />
              </div>
              <h3 className="text-sm font-bold text-[#111827]">Backend Infrastructure</h3>
            </div>
            <span className="text-xs font-semibold text-[#059669] bg-emerald-50 px-2 py-0.5 rounded">
              Active
            </span>
          </div>

          <p className="text-xs text-[#64748B] leading-relaxed">
            Core service configuration and data store connectivity:
          </p>

          <div className="space-y-2 text-xs">
            <div className="p-3 rounded-md border border-[#E5E7EB] bg-[#F5F7FA] flex items-center justify-between">
              <span className="text-[#64748B]">Spring Boot REST API</span>
              <span className="text-[#111827] font-semibold">http://localhost:8080</span>
            </div>
            <div className="p-3 rounded-md border border-[#E5E7EB] bg-[#F5F7FA] flex items-center justify-between">
              <span className="text-[#64748B]">Database Persistence</span>
              <span className="text-[#111827] font-semibold">JPA / Hibernate Repository</span>
            </div>
            <div className="p-3 rounded-md border border-[#E5E7EB] bg-[#F5F7FA] flex items-center justify-between">
              <span className="text-[#64748B]">Incident Endpoint</span>
              <span className="text-[#111827] font-semibold">/incidents</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;

