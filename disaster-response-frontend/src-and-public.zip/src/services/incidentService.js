import apiClient from '../api/client';

const LOCAL_STORAGE_REPORTS_KEY = 'smart_disaster_citizen_reports';
const LOCAL_STORAGE_OPERATIONAL_KEY = 'smart_disaster_operational_meta';

/**
 * Helper to infer default severity based on disaster type
 */
const getDefaultSeverity = (disasterType) => {
  const t = (disasterType || '').toLowerCase();
  if (t.includes('fire') || t.includes('earthquake') || t.includes('tsunami') || t.includes('industrial')) {
    return 'High';
  }
  if (t.includes('flood') || t.includes('cyclone') || t.includes('landslide')) {
    return 'Medium';
  }
  return 'Low';
};

/**
 * Service layer responsible for all Incident REST API communications.
 * Keeps UI components decoupled from HTTP transport logic.
 * Strictly adheres to current Spring Boot API schema: { disasterType, location, status }
 * Manages operational metadata (severity, assignedTeam, responseNotes, verificationInfo)
 */
export const incidentService = {
  /**
   * Fetch all incidents from the backend merged with operational metadata
   * GET /incidents
   * @returns {Promise<Array>} List of incidents
   */
  async getIncidents() {
    const response = await apiClient.get('/incidents');
    const rawList = response.data || [];
    const operationalMap = this.getAllOperationalMetadata();

    return rawList.map((inc) => {
      const meta = operationalMap[inc.id] || {};
      const statusNormalized = (inc.status || 'Pending').trim();
      return {
        ...inc,
        status: statusNormalized,
        severity: meta.severity || getDefaultSeverity(inc.disasterType),
        assignedTeam: meta.assignedTeam || 'Unassigned',
        responseNotes: meta.responseNotes || '',
        source: meta.source || (inc.location?.includes('Sensor') || inc.disasterType === 'Smoke' ? 'SENSOR' : 'MANUAL'),
        reportedAt: meta.reportedAt || null,
        rejectionReason: meta.rejectionReason || null,
        verifiedAt: meta.verifiedAt || null,
        resolvedAt: meta.resolvedAt || null,
      };
    });
  },

  /**
   * Fetch single incident by its ID merged with operational metadata
   * GET /incidents/{id}
   * @param {number|string} id 
   * @returns {Promise<Object>} Incident details
   */
  async getIncidentById(id) {
    const response = await apiClient.get(`/incidents/${id}`);
    const inc = response.data;
    if (!inc) return null;

    const operationalMap = this.getAllOperationalMetadata();
    const meta = operationalMap[inc.id] || {};
    const statusNormalized = (inc.status || 'Pending').trim();

    return {
      ...inc,
      status: statusNormalized,
      severity: meta.severity || getDefaultSeverity(inc.disasterType),
      assignedTeam: meta.assignedTeam || 'Unassigned',
      responseNotes: meta.responseNotes || '',
      source: meta.source || (inc.location?.includes('Sensor') || inc.disasterType === 'Smoke' ? 'SENSOR' : 'MANUAL'),
      reportedAt: meta.reportedAt || null,
      rejectionReason: meta.rejectionReason || null,
      verifiedAt: meta.verifiedAt || null,
      resolvedAt: meta.resolvedAt || null,
    };
  },

  /**
   * Create a new emergency incident
   * POST /incidents
   * Sends strictly supported backend schema: { disasterType, location, status }
   * @param {Object} incidentData
   * @returns {Promise<Object>} Created incident
   */
  async createIncident(incidentData) {
    const payload = {
      disasterType: incidentData.disasterType?.trim(),
      location: incidentData.location?.trim(),
      status: incidentData.status?.trim() || 'Pending',
    };
    const response = await apiClient.post('/incidents', payload);
    const created = response.data;

    // Track operational metadata locally
    if (created && created.id) {
      const initialSeverity = incidentData.severity || getDefaultSeverity(created.disasterType);
      const initialTeam = incidentData.assignedTeam || 'Unassigned';
      const initialNotes = incidentData.responseNotes || incidentData.description || '';
      const source = incidentData.source || 'MANUAL';
      const reportedAt = new Date().toISOString();

      this.saveOperationalMetadata(created.id, {
        severity: initialSeverity,
        assignedTeam: initialTeam,
        responseNotes: initialNotes,
        source: source,
        reportedAt: reportedAt,
      });

      // Track citizen report history for "My Reports" view
      this.saveLocalCitizenReport({
        id: created.id,
        disasterType: created.disasterType,
        location: created.location,
        status: created.status,
        severity: initialSeverity,
        description: incidentData.description || '',
        peopleAffected: incidentData.peopleAffected || 'None',
        latitude: incidentData.latitude || null,
        longitude: incidentData.longitude || null,
        accuracy: incidentData.accuracy || null,
        submittedAt: reportedAt,
        source: source,
      });
    }

    return created;
  },

  /**
   * Update operational parameters of an incident
   * PUT /incidents/{id}
   * Preserves read-only original fields while updating operational fields
   * @param {number|string} id 
   * @param {Object} incidentData - { disasterType, location, status, severity, assignedTeam, responseNotes }
   * @returns {Promise<Object>} Updated incident
   */
  async updateIncident(id, incidentData) {
    const payload = {
      disasterType: incidentData.disasterType?.trim(),
      location: incidentData.location?.trim(),
      status: incidentData.status?.trim(),
    };
    const response = await apiClient.put(`/incidents/${id}`, payload);
    const updated = response.data;

    // Persist operational metadata updates
    const currentMeta = this.getOperationalMetadata(id) || {};
    const newMeta = {
      ...currentMeta,
      severity: incidentData.severity !== undefined ? incidentData.severity : currentMeta.severity || 'Medium',
      assignedTeam: incidentData.assignedTeam !== undefined ? incidentData.assignedTeam : currentMeta.assignedTeam || 'Unassigned',
      responseNotes: incidentData.responseNotes !== undefined ? incidentData.responseNotes : currentMeta.responseNotes || '',
      rejectionReason: incidentData.rejectionReason !== undefined ? incidentData.rejectionReason : currentMeta.rejectionReason || null,
      verifiedAt: incidentData.verifiedAt !== undefined ? incidentData.verifiedAt : currentMeta.verifiedAt || null,
      resolvedAt: incidentData.resolvedAt !== undefined ? incidentData.resolvedAt : currentMeta.resolvedAt || null,
    };
    this.saveOperationalMetadata(id, newMeta);

    return {
      ...updated,
      ...newMeta,
    };
  },

  /**
   * Strict Lifecycle Action: PENDING_VERIFICATION -> ACTIVE
   * Transitions incident to Active status, provisions response team, records verification timestamp
   */
  async verifyAndActivate(id, originalIncident, operationalUpdates = {}) {
    const now = new Date().toISOString();
    return this.updateIncident(id, {
      disasterType: originalIncident.disasterType,
      location: originalIncident.location,
      status: 'Active',
      severity: operationalUpdates.severity || originalIncident.severity || 'High',
      assignedTeam: operationalUpdates.assignedTeam || originalIncident.assignedTeam || 'North Zone Rapid Fire Engine',
      responseNotes: operationalUpdates.responseNotes || originalIncident.responseNotes || 'Verified by authority personnel. Field units dispatched.',
      verifiedAt: now,
    });
  },

  /**
   * Strict Lifecycle Action: PENDING_VERIFICATION -> REJECTED (Resolved with rejection reason)
   * Closes the false/invalid report with an immutable rejection log
   */
  async rejectIncident(id, originalIncident, reason = 'False alarm / Invalid report') {
    const note = `[REJECTED]: ${reason}`;
    const now = new Date().toISOString();
    return this.updateIncident(id, {
      disasterType: originalIncident.disasterType,
      location: originalIncident.location,
      status: 'Resolved',
      severity: 'Low',
      assignedTeam: 'Unassigned',
      responseNotes: originalIncident.responseNotes ? `${originalIncident.responseNotes}\n${note}` : note,
      rejectionReason: reason,
      resolvedAt: now,
    });
  },

  /**
   * Strict Lifecycle Action: ACTIVE -> RESOLVED
   * Marks active response as completed, securing the incident record
   */
  async resolveIncident(id, originalIncident, completionNotes = 'Emergency contained and site secured by response units.') {
    const note = `[RESOLVED]: ${completionNotes}`;
    const now = new Date().toISOString();
    return this.updateIncident(id, {
      disasterType: originalIncident.disasterType,
      location: originalIncident.location,
      status: 'Resolved',
      severity: originalIncident.severity || 'Medium',
      assignedTeam: originalIncident.assignedTeam || 'Unassigned',
      responseNotes: originalIncident.responseNotes ? `${originalIncident.responseNotes}\n${note}` : note,
      resolvedAt: now,
    });
  },

  /**
   * Delete an incident by ID
   * DELETE /incidents/{id}
   * @param {number|string} id 
   * @returns {Promise<boolean>} true if deleted successfully
   */
  async deleteIncident(id) {
    await apiClient.delete(`/incidents/${id}`);
    this.removeLocalCitizenReport(id);
    this.removeOperationalMetadata(id);
    return true;
  },

  /**
   * Quick connectivity probe to test if Spring Boot backend is reachable
   * @returns {Promise<boolean>}
   */
  async checkBackendHealth() {
    try {
      await apiClient.get('/incidents', { timeout: 3500 });
      return true;
    } catch {
      return false;
    }
  },

  /**
   * Operational metadata persistence
   */
  getAllOperationalMetadata() {
    try {
      const data = localStorage.getItem(LOCAL_STORAGE_OPERATIONAL_KEY);
      return data ? JSON.parse(data) : {};
    } catch {
      return {};
    }
  },

  getOperationalMetadata(id) {
    const all = this.getAllOperationalMetadata();
    return all[id] || null;
  },

  saveOperationalMetadata(id, meta) {
    try {
      const all = this.getAllOperationalMetadata();
      all[id] = { ...all[id], ...meta };
      localStorage.setItem(LOCAL_STORAGE_OPERATIONAL_KEY, JSON.stringify(all));
    } catch (e) {
      console.warn('Unable to persist operational metadata', e);
    }
  },

  removeOperationalMetadata(id) {
    try {
      const all = this.getAllOperationalMetadata();
      delete all[id];
      localStorage.setItem(LOCAL_STORAGE_OPERATIONAL_KEY, JSON.stringify(all));
    } catch {
      // Ignore
    }
  },

  /**
   * Citizen local storage metadata helper methods
   */
  getLocalCitizenReports() {
    try {
      const data = localStorage.getItem(LOCAL_STORAGE_REPORTS_KEY);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },

  saveLocalCitizenReport(report) {
    try {
      const existing = this.getLocalCitizenReports();
      const filtered = existing.filter((r) => r.id !== report.id);
      const updated = [report, ...filtered];
      localStorage.setItem(LOCAL_STORAGE_REPORTS_KEY, JSON.stringify(updated));
    } catch (e) {
      console.warn('Unable to persist local citizen report metadata', e);
    }
  },

  removeLocalCitizenReport(id) {
    try {
      const existing = this.getLocalCitizenReports();
      const updated = existing.filter((r) => String(r.id) !== String(id));
      localStorage.setItem(LOCAL_STORAGE_REPORTS_KEY, JSON.stringify(updated));
    } catch {
      // Ignore storage errors
    }
  },
};

export default incidentService;
